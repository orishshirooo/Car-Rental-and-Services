import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, 'src')
sys.path.append(src_dir)

import matplotlib.pyplot as plt
from PyQt6.QtWidgets import QApplication

from app import RentalApp
from utils import FORMAL_LIGHT_STYLESHEET

if __name__ == "__main__":
    try:

        plt.switch_backend('QtAgg')

        app = QApplication(sys.argv)
        app.setStyleSheet(FORMAL_LIGHT_STYLESHEET)

        window = RentalApp()
        window.show()

        sys.exit(app.exec())

    except ImportError as e:
        print(f"Import Error: {e}")
        print("Ensure all files (app.py, utils.py, widgets.py, etc.) are in the 'src' folder.")
    except Exception as e:
        print(f"An application error occurred: {e}")