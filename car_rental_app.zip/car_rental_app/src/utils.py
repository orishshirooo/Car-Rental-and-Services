from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.units import inch

import datetime
import sys
import os
import shutil
import uuid
import hashlib
from PyQt6.QtGui import QIcon, QPixmap, QColor
from PyQt6.QtCore import Qt

# --- Visual Styling ---
# Sets the colors, fonts, and borders for the application (Dark Mode).
FORMAL_LIGHT_STYLESHEET = """
    QWidget { background-color: #1e1e1e; color: #dddddd; }
    QLabel, QCheckBox { font-size: 10pt; background-color: transparent; color: #dddddd; }
    QLabel a { color: #0078d4; }
    QLineEdit, QTextEdit, QComboBox { background-color: #252526; color: #dddddd; padding: 8px; border: 1px solid #444444; border-radius: 4px; }
    QLineEdit:focus, QTextEdit:focus, QComboBox:focus { border: 1px solid #0078d4; }
    QLineEdit:read-only { background-color: #333333; }
    QComboBox::drop-down { border: none; }
    QComboBox QAbstractItemView { background-color: #252526; color: #dddddd; border: 1px solid #444444; selection-background-color: #0078d4; selection-color: white; }
    QGroupBox { background-color: #1e1e1e; border: 1px solid #444444; border-radius: 5px; margin-top: 10px; padding: 15px; font-size: 10pt; color: #dddddd; }
    QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 10px; color: #aaaaaa; font-weight: bold; }
    QScrollArea { border: none; background-color: #1e1e1e; }
    QScrollArea > QWidget > QWidget { background-color: #1e1e1e; }
    QDialog { background-color: #1e1e1e; }
    QTableWidget { background-color: #252526; border: 1px solid #444444; gridline-color: #444444; color: #dddddd; }
    QHeaderView::section { background-color: #2d2d2d; padding: 5px; border-bottom: 2px solid #0078d4; border-right: 1px solid #444444; font-weight: bold; color: #eeeeee; }
    QPushButton { background-color: #0078d4; color: white; border: none; border-radius: 5px; padding: 10px; font-size: 10pt; font-weight: bold; }
    QPushButton:hover { background-color: #005a9e; }
    QPushButton#DangerButton { background-color: #e74c3c; }
    QPushButton#DangerButton:hover { background-color: #c0392b; }
    QPushButton#SecondaryButton { background-color: #444444; color: white; font-size: 9pt; padding: 5px 8px; font-weight: normal; }
    QPushButton#SecondaryButton:hover { background-color: #555555; }
    QWidget#Sidebar { background-color: #1e1e1e; border-right: 1px solid #333333; }
    QWidget#Sidebar QLabel { color: #0078d4; font-weight: bold; font-size: 11pt; background-color: transparent; }
    QWidget#Sidebar QPushButton { background-color: transparent; color: #bbbbbb; padding: 12px 10px; border: none; text-align: left; margin: 5px 10px; border-radius: 4px; font-weight: bold; }
    QWidget#Sidebar QPushButton:hover { background-color: #333333; color: #0078d4; }
"""

# --- General Tools ---
# Basic functions for file paths, security, and text formatting.

def resource_path(relative_path):
    try: base_path = sys._MEIPASS
    except Exception: base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def format_peso(amount):
    return f"P {amount:,.2f}"

# --- Image Manager ---
# Handles loading, saving, and resizing car images and icons.

def get_assets_dir():
    base_path = os.path.dirname(os.path.abspath(sys.argv[0]))
    return os.path.join(base_path, "assets")

def get_car_image_dir():
    return os.path.join(get_assets_dir(), "cars")

def load_pixmap(filename, width=None, height=None):
    try:
        pixmap = QPixmap(resource_path(filename))
        if width and height:
            return pixmap.scaled(width, height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        return pixmap
    except Exception: return QPixmap()

def load_icon(filename):
    try: return QIcon(resource_path(filename))
    except Exception: return QIcon()

def save_car_image(source_path):
    if not source_path or not os.path.exists(source_path): return None
    target_dir = get_car_image_dir()
    os.makedirs(target_dir, exist_ok=True)
    ext = os.path.splitext(source_path)[1]
    unique_filename = f"{uuid.uuid4().hex}{ext}"
    target_path = os.path.join(target_dir, unique_filename)
    try:
        shutil.copy2(source_path, target_path)
        return unique_filename
    except Exception as e:
        print(f"Error saving image: {e}")
        return None

def load_car_pixmap(filename, width, height):
    try:
        if filename:
            full_path = os.path.join(get_car_image_dir(), filename)
            if os.path.exists(full_path):
                pixmap = QPixmap(full_path)
                if not pixmap.isNull():
                     return pixmap.scaled(width, height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
    except Exception: pass

    try:
        placeholder_path = os.path.join(get_assets_dir(), "placeholder.png")
        if os.path.exists(placeholder_path):
             pixmap = QPixmap(placeholder_path)
             return pixmap.scaled(width, height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
    except Exception: pass

    blank = QPixmap(width, height)
    blank.fill(QColor("#333333"))
    return blank


# --- PDF Generator ---
# Creates the printable invoice with rental details and total cost.

def generate_invoice_pdf(filepath, data):
    c = canvas.Canvas(filepath, pagesize=letter)
    width, height = letter

    # Page Layout Coordinates
    MARGIN_X = 1.0 * inch
    LINE_HEIGHT = 0.2 * inch
    START_Y = height - 1.5 * inch
    DESCRIPTION_X = MARGIN_X
    AMOUNT_X = width - MARGIN_X

    # 1. Header Information
    c.setFont("Helvetica-Bold", 20)
    c.drawString(DESCRIPTION_X, height - 1 * inch, "RAGADIO RENTALS")
    c.setFont("Helvetica", 12)
    c.drawString(DESCRIPTION_X, height - 1.25 * inch, "Official Sales Invoice")

    # 2. Customer Details
    c.setFont("Helvetica", 10)
    c.drawString(DESCRIPTION_X, START_Y + 0.1 * inch, f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    c.drawString(DESCRIPTION_X, START_Y - 0.05 * inch, f"Customer: {data['user_name']}")
    c.drawString(DESCRIPTION_X, START_Y - 0.2 * inch, f"Email: {data.get('user_email', 'N/A')}")

    y = START_Y - 0.5 * inch

    # 3. Table Column Headers
    c.setFont("Helvetica-Bold", 12)
    c.drawString(DESCRIPTION_X, y, "Description")
    c.drawRightString(AMOUNT_X, y, "Amount")

    # Separator Line
    c.setStrokeColor(colors.grey)
    c.line(DESCRIPTION_X, y - 5, AMOUNT_X, y - 5)

    y -= LINE_HEIGHT

    # 4. Itemized List (Car + Services)
    c.setFont("Helvetica", 11)
    car_desc = f"Vehicle Rental: {data['car'].name} ({data['duration']} Days)"
    c.drawString(DESCRIPTION_X, y, car_desc)
    c.drawRightString(AMOUNT_X, y, format_peso(data['base_total']))
    y -= LINE_HEIGHT

    if data["services"]:
        c.setFont("Helvetica", 10)
        for svc in data['services']:
            c.drawString(DESCRIPTION_X + 0.2 * inch, y, f"+ {svc['name']}")
            c.drawRightString(AMOUNT_X, y, format_peso(svc['cost']))
            y -= LINE_HEIGHT

    # 5. Total Calculation
    y -= 0.1 * inch
    c.line(DESCRIPTION_X, y, AMOUNT_X, y)

    y -= LINE_HEIGHT
    c.setFont("Helvetica-Bold", 14)
    c.drawString(DESCRIPTION_X, y, "TOTAL PAID:")
    c.drawRightString(AMOUNT_X, y, format_peso(data['final_total']))

    # 6. Footer Message
    c.setFont("Helvetica-Oblique", 10)
    c.drawString(DESCRIPTION_X, 1 * inch, "Thank you for choosing Ragadio Rentals. Drive safely!")

    c.save()