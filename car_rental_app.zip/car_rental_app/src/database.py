import sys
import datetime
import pymysql
from PyQt6.QtWidgets import QMessageBox
from utils import hash_password
from models import Car, Transaction

DB_HOST = "localhost"
DB_USER = "root"
DB_PASS = ""
DB_NAME = "car_rental_db"

# --- Database Handler ---
# This class connects to the MySQL database and handles all
# saving, loading, and updating of data (users, cars, bookings).
class DBManager:
    def __init__(self):
        self.conn, self.cursor = None, None
        self.connect()

    def connect(self):
        try:
            self.conn = pymysql.connect(
                host=DB_HOST,
                user=DB_USER,
                password=DB_PASS,
                database=DB_NAME,
                cursorclass=pymysql.cursors.DictCursor
            )
            self.cursor = self.conn.cursor()
            self._check_tables()
            self._insert_initial_data()
        except pymysql.Error as err:
            QMessageBox.critical(None, "Database Error", f"Connection failed: {err}\nCheck if XAMPP/MySQL is running.")
            sys.exit(1)

    def _check_tables(self):
        try:
            # Check Car columns
            self.cursor.execute("SHOW COLUMNS FROM cars LIKE 'quantity'")
            if not self.cursor.fetchone():
                self.cursor.execute("ALTER TABLE cars ADD COLUMN quantity INT DEFAULT 1")

            self.cursor.execute("SHOW COLUMNS FROM cars LIKE 'image_path'")
            if not self.cursor.fetchone():
                self.cursor.execute("ALTER TABLE cars ADD COLUMN image_path VARCHAR(255) DEFAULT NULL")

            # Check Message columns
            self.cursor.execute("SHOW TABLES LIKE 'messages'")
            if self.cursor.fetchone():
                self.cursor.execute("SHOW COLUMNS FROM messages LIKE 'id'")
                if not self.cursor.fetchone():
                    self.cursor.execute("ALTER TABLE messages ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY FIRST")
                self.cursor.execute("SHOW COLUMNS FROM messages LIKE 'admin_reply'")
                if not self.cursor.fetchone():
                    self.cursor.execute("ALTER TABLE messages ADD COLUMN admin_reply TEXT DEFAULT NULL")

            # Check Transaction columns
            self.cursor.execute("SHOW COLUMNS FROM transactions LIKE 'status'")
            if not self.cursor.fetchone():
                self.cursor.execute("ALTER TABLE transactions ADD COLUMN status VARCHAR(20) DEFAULT 'Active'")

            self.conn.commit()
        except pymysql.Error:
            pass

    def _insert_initial_data(self):
        try:
            categories = [('1', '6 Seaters (SUVs, MPVs, Vans)'), ('2', '4 Seaters (Sedans & Specialty)'),
                          ('3', '2-Seater (Sports Car / Cargo)'), ('4', '4-Seater (Compact / Hatchback)'),
                          ('5', '5-Seater (Sedan / Crossover)'), ('6', '8-Seater (Full-Size SUV)'),
                          ('7', 'Van (10-15 Seater)')]
            for c in categories:
                try:
                    self.cursor.execute("INSERT INTO categories (id, name) VALUES (%s, %s)", c)
                except:
                    pass

            # Default User
            self.cursor.execute("SELECT COUNT(*) AS count FROM users WHERE email = 'test@user.com'")
            if self.cursor.fetchone()['count'] == 0:
                self.cursor.execute("INSERT INTO users (name, email, password_hash) VALUES (%s, %s, %s)",
                                    ("Test User", "test@user.com", hash_password("password")))

            self.conn.commit()
        except:
            pass

    # --- USER AUTH ---
    def register_user(self, name, email, password_hash):
        try:
            self.cursor.execute("INSERT INTO users (name, email, password_hash) VALUES (%s, %s, %s)",
                                (name, email, password_hash))
            self.conn.commit()
            return True
        except pymysql.IntegrityError:
            return "Email already registered."
        except pymysql.Error as e:
            return str(e)

    def login_user(self, email, password_hash):
        self.cursor.execute("SELECT id, name, email FROM users WHERE email = %s AND password_hash = %s",
                            (email, password_hash))
        return self.cursor.fetchone()

    # --- CARS ---
    def get_all_cars_data(self, only_available=False):
        query = """
            SELECT c.id, c.name, c.price_per_day, c.is_available, c.quantity, c.image_path, c.category_id, 
                   COALESCE(cat.name, 'Unknown Category') as category_name
            FROM cars c
            LEFT JOIN categories cat ON c.category_id = cat.id
        """
        if only_available: query += " WHERE c.is_available = 1 AND c.quantity > 0"
        self.cursor.execute(query + " ORDER BY c.category_id, c.name")
        return self.cursor.fetchall()

    def get_cars_by_category(self, category_id, only_available=False):
        query = "SELECT id, name, price_per_day, is_available, quantity, image_path FROM cars WHERE category_id = %s"
        if only_available: query += " AND is_available = 1 AND quantity > 0"
        self.cursor.execute(query, (category_id,))
        # Return Car Objects
        return [Car(c['id'], c['name'], c['price_per_day'], bool(c['is_available']), c['quantity'], c['image_path']) for
                c in self.cursor.fetchall()]

    def update_car_availability(self, car_id, is_available):
        self.cursor.execute("UPDATE cars SET is_available = %s WHERE id = %s", (int(is_available), car_id))
        self.conn.commit()

    def add_car(self, category_id, name, price, quantity, image_filename):
        try:
            self.cursor.execute(
                "INSERT INTO cars (category_id, name, price_per_day, is_available, quantity, image_path) VALUES (%s, %s, %s, %s, %s, %s)",
                (category_id, name, price, 1, quantity, image_filename)
            )
            self.conn.commit()
            return True
        except Exception as e:
            return str(e)

    def edit_car(self, car_id, name, price, category_id, quantity, image_filename):
        try:
            if image_filename:
                query = "UPDATE cars SET name=%s, price_per_day=%s, category_id=%s, quantity=%s, image_path=%s WHERE id=%s"
                params = (name, price, category_id, quantity, image_filename, car_id)
            else:
                query = "UPDATE cars SET name=%s, price_per_day=%s, category_id=%s, quantity=%s WHERE id=%s"
                params = (name, price, category_id, quantity, car_id)
            self.cursor.execute(query, params)
            self.conn.commit()
            return True
        except Exception as e:
            return str(e)

    def delete_car(self, car_id):
        try:
            self.cursor.execute("DELETE FROM cars WHERE id = %s", (car_id,))
            self.conn.commit()
            return True
        except:
            return "Cannot delete car (linked to transactions)."

    # --- SERVICES ---
    def get_all_services(self):
        self.cursor.execute("SELECT name, price, is_daily FROM services ORDER BY name")
        return self.cursor.fetchall()

    def get_all_services_with_ids(self):
        self.cursor.execute("SELECT id, name, price, is_daily FROM services ORDER BY name")
        return self.cursor.fetchall()

    def add_service(self, name, price, is_daily):
        try:
            self.cursor.execute("INSERT INTO services (name, price, is_daily) VALUES (%s, %s, %s)",
                                (name, price, int(is_daily)))
            self.conn.commit()
            return True
        except:
            return "Error adding service."

    def delete_service(self, service_id):
        try:
            self.cursor.execute("DELETE FROM services WHERE id = %s", (service_id,))
            self.conn.commit()
            return True
        except:
            return "Error deleting service."

    # --- TRANSACTIONS ---
    def create_booking_atomic(self, txn):
        try:
            self.conn.begin()
            self.cursor.execute("SELECT quantity FROM cars WHERE id = %s FOR UPDATE", (txn.car.id,))
            res = self.cursor.fetchone()
            if not res or res['quantity'] < 1:
                self.conn.rollback()
                return "Vehicle became unavailable."

            services_str = ", ".join([f"{s['name']} (P{s['cost']})" for s in txn.services])
            query = "INSERT INTO transactions (user_id, timestamp, user_name, user_email, car_model, duration, services_used, final_total, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'Active')"
            data = (txn.user.get('id'), txn.timestamp, txn.user.get('name'), txn.user.get('email'), txn.car.name,
                    txn.duration, services_str, txn.final_total)
            self.cursor.execute(query, data)

            new_qty = res['quantity'] - 1
            self.cursor.execute("UPDATE cars SET quantity = %s WHERE id = %s", (new_qty, txn.car.id))
            if new_qty <= 0:
                self.cursor.execute("UPDATE cars SET is_available = 0 WHERE id = %s", (txn.car.id,))

            self.conn.commit()
            return True
        except Exception as e:
            self.conn.rollback()
            return str(e)

    def return_vehicle(self, txn_id, car_name):
        try:
            self.conn.begin()
            self.cursor.execute("UPDATE transactions SET status = 'Returned' WHERE id = %s", (txn_id,))
            self.cursor.execute("UPDATE cars SET quantity = quantity + 1, is_available = 1 WHERE name = %s",
                                (car_name,))
            self.conn.commit()
            return True
        except Exception as e:
            self.conn.rollback()
            return str(e)

    def get_all_categories(self):
        self.cursor.execute("SELECT id, name FROM categories ORDER BY id")
        return self.cursor.fetchall()

    def get_categories(self):
        return self.get_all_categories()

    def _build_transactions_from_rows(self, rows):
        txns = []
        for r in rows:
            dummy_car = Car(0, r['car_model'], 0, image_path=None)
            user = {"id": r.get('user_id'), "name": r['user_name'], "email": r['user_email']}
            txn = Transaction(r.get('id'), user, dummy_car, r.get('duration', 0), [], r.get('final_total', 0),
                              r.get('status', 'Active'))
            txn.timestamp = r.get('timestamp')
            txns.append(txn)
        return txns

    def get_active_rentals(self):
        self.cursor.execute("SELECT * FROM transactions WHERE status = 'Active' ORDER BY timestamp DESC")
        return self._build_transactions_from_rows(self.cursor.fetchall())

    def get_all_transactions(self):
        self.cursor.execute("SELECT * FROM transactions ORDER BY timestamp DESC")
        return self._build_transactions_from_rows(self.cursor.fetchall())

    def get_transaction_by_id(self, txn_id):
        self.cursor.execute("SELECT * FROM transactions WHERE id = %s", (txn_id,))
        return self._build_transactions_from_rows(self.cursor.fetchall())

    def get_transactions_by_user_id(self, uid):
        self.cursor.execute("SELECT * FROM transactions WHERE user_id = %s ORDER BY timestamp DESC", (uid,))
        return self._build_transactions_from_rows(self.cursor.fetchall())

    def get_transactions_by_date_range(self, start, end):
        query = "SELECT * FROM transactions WHERE timestamp BETWEEN %s AND %s ORDER BY timestamp DESC"
        self.cursor.execute(query, (start, end))
        return self._build_transactions_from_rows(self.cursor.fetchall())

    # --- MESSAGES ---
    def save_message(self, name, email, text):
        self.cursor.execute(
            "INSERT INTO messages (timestamp, user_name, user_email, message_text) VALUES (%s, %s, %s, %s)",
            (datetime.datetime.now(), name, email, text))
        self.conn.commit()

    def get_messages_by_email(self, email):
        self.cursor.execute("SELECT * FROM messages WHERE user_email = %s ORDER BY timestamp ASC", (email,))
        return self.cursor.fetchall()

    def get_my_messages(self, email):
        return self.get_messages_by_email(email)

    def get_all_messages(self):
        self.cursor.execute("SELECT * FROM messages ORDER BY timestamp DESC")
        return self.cursor.fetchall()

    def save_reply(self, msg_id, text):
        try:
            self.cursor.execute("UPDATE messages SET admin_reply = %s WHERE id = %s", (text, msg_id))
            self.conn.commit()
            return True
        except Exception as e:
            return str(e)

    def close(self):
        if self.cursor: self.cursor.close()
        if self.conn: self.conn.close()

    def cancel_transaction_by_id(self, txn_id, car_name):
        try:
            self.conn.begin()
            self.cursor.execute("DELETE FROM transactions WHERE id = %s", (txn_id,))
            self.cursor.execute("UPDATE cars SET quantity = quantity + 1, is_available = 1 WHERE name = %s",
                                (car_name,))
            self.conn.commit()
            return True
        except Exception as e:
            self.conn.rollback()
            return str(e)

    def find_and_cancel_active_rental(self, car_name, user_id):
        try:
            self.conn.begin()
            self.cursor.execute("""
                SELECT id FROM transactions 
                WHERE user_id = %s AND car_model = %s AND status = 'Active'
                ORDER BY timestamp DESC LIMIT 1
            """, (user_id, car_name))

            result = self.cursor.fetchone()
            if not result:
                self.conn.rollback()
                return "Error: No active booking found for this car and user."

            txn_id = result['id']

            self.cursor.execute("DELETE FROM transactions WHERE id = %s", (txn_id,))
            self.cursor.execute("UPDATE cars SET quantity = quantity + 1, is_available = 1 WHERE name = %s",
                                (car_name,))

            self.conn.commit()
            return True

        except Exception as e:
            self.conn.rollback()
            return str(e)