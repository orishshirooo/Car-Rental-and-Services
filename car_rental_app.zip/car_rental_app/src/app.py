from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QStackedWidget, QMessageBox
from PyQt6.QtGui import QIcon
from PyQt6.QtCore import QTimer

from utils import load_icon
from database import DBManager
from manager import RentalManager
from widgets import (
    AuthWidget,
    VehicleListWidget,
    OptionsWidget,
    ReceiptWidget,
    AdminDashboardWidget,
    MessageWidget,
    SidebarWidget,
    CustomerHistoryWidget
)

# --- Main Application Window ---
# This class acts as the "Traffic Controller," switching the screen
# between Login, Customer Booking, and Admin Dashboard.
class RentalApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ragadio's Car Rentals")

        icon = load_icon("ragadio logo")
        if not icon.isNull():
            self.setWindowIcon(icon)

        self.db = DBManager()
        self.manager = RentalManager(self.db)

        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.sidebar = SidebarWidget(self.manager)

        self.sidebar.hide()
        layout.addWidget(self.sidebar)

        self.stack = QStackedWidget()
        layout.addWidget(self.stack)

        self.setCentralWidget(container)

        self.init_widgets()
        self.setup_connections()

        self.setFixedSize(1525, 825)

    def init_widgets(self):
        self.auth_w = AuthWidget(self.manager)
        self.vehicle_list_w = VehicleListWidget(self.manager)
        self.options_w = OptionsWidget(self.manager)
        self.receipt_w = ReceiptWidget()
        self.admin_dashboard_w = AdminDashboardWidget(self.manager)
        self.message_w = MessageWidget(self.manager)
        self.history_w = CustomerHistoryWidget(self.manager)

        for w in [self.auth_w, self.vehicle_list_w, self.options_w, self.receipt_w,
                  self.admin_dashboard_w, self.message_w, self.history_w]:
            self.stack.addWidget(w)

        self.stack.setCurrentWidget(self.auth_w)

    def setup_connections(self):
        # --- Auth Connections ---
        self.auth_w.customer_login_successful.connect(self.on_customer_login)
        self.auth_w.admin_login_successful.connect(self.on_admin_login)

        # --- Sidebar Connections ---
        self.sidebar.logout_requested.connect(self.on_logout)
        self.sidebar.vehicle_list_requested.connect(self.on_click_all_vehicles)
        self.sidebar.message_center_requested.connect(self.go_to_message_center)
        self.sidebar.history_requested.connect(self.go_to_history)
        self.sidebar.category_selected.connect(self.vehicle_list_w.update_car_list)

        # --- Customer Flow Connections ---
        self.vehicle_list_w.proceed_requested.connect(self.go_to_options)
        self.options_w.booking_confirmed.connect(self.on_booking_confirmed)
        self.options_w.back_to_vehicles.connect(self.go_to_vehicle_list)
        self.receipt_w.start_new_rental.connect(self.go_to_vehicle_list)
        self.receipt_w.cancel_requested.connect(self.on_booking_canceled)

        # --- Admin Connections ---
        self.admin_dashboard_w.signout_requested.connect(self.on_logout)
        self.admin_dashboard_w.availability_updated.connect(self.refresh_customer_vehicle_list_in_background)
        self.admin_dashboard_w.services_updated.connect(self.refresh_customer_options_in_background)

        # --- Message Widget Connections ---
        self.message_w.message_sent.connect(self.on_message_sent)
        self.message_w.back_to_main.connect(self.go_to_vehicle_list)

    # --- SLOTS (Functions) ---

    def refresh_customer_vehicle_list_in_background(self):
        self.vehicle_list_w.update_car_list(self.vehicle_list_w.current_filter_id)

    def refresh_customer_options_in_background(self):
        self.options_w.refresh_services_list()

    def on_customer_login(self, name, email):
        self.vehicle_list_w.update_welcome_message(name)

        user_id = self.manager.current_user.get('id', 0)
        self.sidebar.set_user_details(name, email, user_id)

        self.go_to_vehicle_list()
        self.sidebar.show()

    def on_admin_login(self):
        self.manager.current_user = {"id": 0, "name": "Administrator", "email": "admin@gmail.com"}

        self.admin_dashboard_w.sales_tab.handle_reset()
        self.admin_dashboard_w.active_rentals_tab.populate_table()
        self.admin_dashboard_w.inventory_tab.populate_availability_table()
        self.admin_dashboard_w.messages_tab.populate_message_table()
        self.admin_dashboard_w.inventory_tab.populate_categories_dropdown()
        self.admin_dashboard_w.inventory_tab.populate_services_table()

        self.sidebar.hide()
        self.stack.setCurrentWidget(self.admin_dashboard_w)

    def on_logout(self):
        self.manager.logout()
        self.auth_w.reset_view()
        self.stack.setCurrentWidget(self.auth_w)
        self.sidebar.hide()

    def go_to_vehicle_list(self):
        self.vehicle_list_w.update_car_list(self.vehicle_list_w.current_filter_id)
        self.stack.setCurrentWidget(self.vehicle_list_w)

    def on_click_all_vehicles(self):
        self.vehicle_list_w.update_car_list(None)
        self.stack.setCurrentWidget(self.vehicle_list_w)

    def go_to_options(self, car):
        self.options_w.update_view(car)
        self.stack.setCurrentWidget(self.options_w)

    def go_to_history(self):
        user = self.manager.current_user
        if user and user.get('id'):
            self.history_w.populate_table(user['id'])
            self.stack.setCurrentWidget(self.history_w)

    def go_to_message_center(self):
        user = self.manager.current_user
        self.message_w.set_user_details(user.get('name'), user.get('email'))
        self.stack.setCurrentWidget(self.message_w)

    def on_booking_confirmed(self, data):
        self.manager.record_transaction(data)
        self.receipt_w.update_receipt(self.manager.current_user['name'], data)
        self.stack.setCurrentWidget(self.receipt_w)
        self.vehicle_list_w.update_car_list(self.vehicle_list_w.current_filter_id)

    def on_message_sent(self):
        QMessageBox.information(self, "Message Sent",
                                "Thank you! Your message/ticket has been submitted.")
        self.go_to_vehicle_list()

    def on_booking_canceled(self, data):
        car_name = data['car'].name
        user_id = self.manager.current_user.get('id')

        result = self.manager.cancel_transaction(car_name, user_id)

        if result is True:
            QMessageBox.information(self, "Cancellation Success",
                                    f"Booking for {car_name} canceled. Stock restored.")
            QTimer.singleShot(100, self.go_to_vehicle_list)
        else:
            QMessageBox.critical(self, "Cancellation Failed",
                                 f"Database error: {result}")
            QTimer.singleShot(100, self.go_to_vehicle_list)

    def closeEvent(self, e):
        print("Closing database connection...")
        self.db.close()
        super().closeEvent(e)