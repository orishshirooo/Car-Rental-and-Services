from utils import hash_password, save_car_image
from models import Transaction
from database import DBManager

# --- Logic Manager ---
# This class acts as the "Middleman" between the Interface (App) and
# the Database. It processes user requests and tells the Database what to do.
class RentalManager:
    def __init__(self, db_manager: DBManager):
        self.db = db_manager
        self.current_user = {"id": None, "name": "", "email": ""}

    def get_categories(self): return self.db.get_all_categories()

    def get_cars(self, cat_id): return self.db.get_cars_by_category(cat_id, only_available=True)

    def get_services(self): return self.db.get_all_services()

    def register(self, name, email, password): return self.db.register_user(name, email, hash_password(password))

    def login(self, email, password):
        user_data = self.db.login_user(email, hash_password(password))
        if user_data:
            self.current_user = {"id": user_data['id'], "name": user_data['name'], "email": user_data['email']}
            return True
        return False

    def logout(self): self.current_user = {"id": None, "name": "", "email": ""}

    def record_transaction(self, data):
        txn = Transaction(None, self.current_user, data["car"], data["duration"], data["services"], data["final_total"])
        return self.db.create_booking_atomic(txn)

    def get_active_rentals(self): return self.db.get_active_rentals()

    def return_rental(self, txn_id, car_name): return self.db.return_vehicle(txn_id, car_name)

    def save_message(self, name, email, message): self.db.save_message(name, email, message)

    def get_all_cars_for_admin(self): return self.db.get_all_cars_data(only_available=False)

    def add_new_car(self, category_id, name, price, quantity, source_image_path):
        saved_filename = save_car_image(source_image_path)
        return self.db.add_car(category_id, name, price, quantity, saved_filename)

    def edit_car(self, car_id, name, price, category_id, quantity, source_image_path):
        saved_filename = save_car_image(source_image_path) if source_image_path else None
        return self.db.edit_car(car_id, name, price, category_id, quantity, saved_filename)

    def delete_car(self, car_id): return self.db.delete_car(car_id)

    def update_car_unit_availability(self, car_id, is_available): self.db.update_car_availability(car_id, is_available)

    def get_all_services_with_ids(self): return self.db.get_all_services_with_ids()

    def add_new_service(self, name, price, is_daily): return self.db.add_service(name, price, is_daily)

    def delete_service(self, service_id): return self.db.delete_service(service_id)

    def get_all_transactions(self): return self.db.get_all_transactions()

    def get_transactions_by_user_id(self, user_id): return self.db.get_transactions_by_user_id(user_id)

    def get_transaction_by_id(self, txn_id):
        return self.db.get_transaction_by_id(txn_id)

    def get_all_messages(self): return self.db.get_all_messages()

    def send_reply(self, message_id, reply_text): return self.db.save_reply(message_id, reply_text)

    def get_my_messages(self, email): return self.db.get_messages_by_email(email)

    def get_transactions_by_range(self, start, end): return self.db.get_transactions_by_date_range(start, end)

    def cancel_transaction(self, car_name, user_id):
        return self.db.find_and_cancel_active_rental(car_name, user_id)