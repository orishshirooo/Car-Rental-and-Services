import datetime
from utils import format_peso

# --- Vehicle Model ---
# Represents a single car in the inventory with its details and status.
class Car:
    def __init__(self, id, name, price_per_day, is_available=True, quantity=1, image_path=None):
        self._id = id
        self._name = name
        self._price = price_per_day
        self._is_available = is_available
        self._quantity = quantity
        self._image_path = image_path

    @property
    def id(self): return self._id

    @property
    def name(self): return self._name

    @property
    def price_per_day(self): return self._price

    @property
    def is_available(self): return self._is_available

    @property
    def quantity(self): return self._quantity

    @property
    def image_path(self): return self._image_path

    def to_string(self):
        status = " (Available)" if self._is_available else " (UNAVAILABLE)"
        return f"{self._name} - {format_peso(self._price)} / day{status}"


# --- Transaction Model ---
# Represents a completed rental booking with customer and payment info.
class Transaction:
    def __init__(self, id, user, car, duration, services, final_total, status="Active"):
        self.id = id
        self.timestamp = datetime.datetime.now()
        self.user = user
        self.car = car
        self.duration = duration
        self.services = services
        self.final_total = final_total
        self.status = status