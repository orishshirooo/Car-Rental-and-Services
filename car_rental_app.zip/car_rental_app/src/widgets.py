import sys
import datetime
import re
import matplotlib.ticker as ticker
import os
from datetime import timedelta
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QStackedWidget,
    QGridLayout, QMessageBox, QGroupBox, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QSizePolicy,
    QScrollArea, QTextEdit, QSpacerItem, QComboBox,
    QDialog, QFormLayout, QDialogButtonBox, QFrame,
    QFileDialog
)
# CRITICAL IMPORT: QTimer is required for the crash fix
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QIntValidator, QPixmap, QIcon, QDoubleValidator, QColor
from PyQt6.QtWidgets import QDateEdit  # Add QDateEdit
from PyQt6.QtCore import QDate         # Add QDate
from PyQt6.QtWidgets import QTabWidget

from PyQt6.QtWidgets import QCalendarWidget
from utils import format_peso, load_pixmap, load_icon, generate_invoice_pdf, load_car_pixmap


# --- 1. Base Class ---

class BaseWidget(QWidget):
    def __init__(self):
        super().__init__()

    def create_label(self, text, bold=False, size=12):
        lbl = QLabel(text)
        if bold:
            lbl.setFont(QFont("Arial", size, QFont.Weight.Bold))
        return lbl


# --- 2. Auth Widgets ---

class LoginWidget(BaseWidget):
    customer_login_successful = pyqtSignal(str, str)
    register_requested = pyqtSignal()
    admin_login_successful = pyqtSignal()

    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(15)

        layout.addWidget(self.create_label("Customer Login", True, 18), alignment=Qt.AlignmentFlag.AlignCenter)

        self.email_in = QLineEdit()
        self.email_in.setPlaceholderText("Email Address")
        self.email_in.setMinimumWidth(300)

        self.password_in = QLineEdit()
        self.password_in.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_in.setPlaceholderText("Password")
        self.password_in.setMinimumWidth(300)
        self.password_in.returnPressed.connect(self.handle_login)

        # --- Show Password Checkbox (Fixed Style) ---
        self.show_pass_cb = QCheckBox("Show Password")
        self.show_pass_cb.setCursor(Qt.CursorShape.PointingHandCursor)

        # This stylesheet forces the box to be visible
        self.show_pass_cb.setStyleSheet("""
            QCheckBox { 
                color: #ccc; 
                margin-top: 5px; 
                spacing: 8px;
            }
            QCheckBox::indicator { 
                width: 18px; 
                height: 18px; 
                border: 1px solid #666; 
                border-radius: 4px; 
                background-color: #252526; 
            }
            QCheckBox::indicator:checked { 
                background-color: #0078d4; 
                border: 1px solid #0078d4;
                image: none;
            }
        """)

        self.show_pass_cb.toggled.connect(lambda checked: self.password_in.setEchoMode(
            QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password))
        # --------------------------------------------

        login_btn = QPushButton("Log In")
        login_btn.clicked.connect(self.handle_login)

        signup_lbl = QLabel("<a href='#'>Don't have an account? Sign Up</a>")
        signup_lbl.linkActivated.connect(self.register_requested.emit)

        auth_box = QGroupBox()
        auth_box.setLayout(QVBoxLayout())
        auth_box.layout().addWidget(QLabel("Email:"))
        auth_box.layout().addWidget(self.email_in)
        auth_box.layout().addWidget(QLabel("Password:"))
        auth_box.layout().addWidget(self.password_in)

        # Add checkbox to layout
        auth_box.layout().addWidget(self.show_pass_cb)

        auth_box.layout().setContentsMargins(50, 10, 50, 10)
        auth_box.setTitle("Login Credentials")

        layout.addWidget(auth_box, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(login_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(signup_lbl, alignment=Qt.AlignmentFlag.AlignCenter)

    def handle_login(self):
        email, password = self.email_in.text().strip(), self.password_in.text()
        if not (email and password):
            QMessageBox.warning(self, "Error", "Please enter both email and password.")
            return

        if email.lower() == "admin@gmail.com" and password == "admin123":
            self.admin_login_successful.emit()
            self.email_in.clear()
            self.password_in.clear()
        elif self.manager.login(email, password):
            self.customer_login_successful.emit(self.manager.current_user['name'], email)
            self.email_in.clear()
            self.password_in.clear()
        else:
            QMessageBox.critical(self, "Login Failed", "Invalid email or password.")
            self.password_in.clear()


class SignupWidget(BaseWidget):
    registration_successful = pyqtSignal(str, str)
    login_requested = pyqtSignal()

    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(15)

        layout.addWidget(self.create_label("Create Account", True, 18), alignment=Qt.AlignmentFlag.AlignCenter)

        self.name_in = QLineEdit()
        self.name_in.setPlaceholderText("Full Name")
        self.email_in = QLineEdit()
        self.email_in.setPlaceholderText("e.g. russeljohnlasapragadio@gmail.com")
        self.password_in = QLineEdit()
        self.password_in.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_in.setPlaceholderText("Password (min. 8 characters)")
        self.confirm_password_in = QLineEdit()
        self.confirm_password_in.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_password_in.setPlaceholderText("Confirm Password")
        self.confirm_password_in.returnPressed.connect(self.handle_signup)

        signup_btn = QPushButton("Sign Up")
        signup_btn.clicked.connect(self.handle_signup)
        login_lbl = QLabel("<a href='#'>Already have an account? Log In</a>")
        login_lbl.linkActivated.connect(self.login_requested.emit)

        auth_box = QGroupBox()
        form_layout = QGridLayout()
        form_layout.addWidget(QLabel("Name:"), 0, 0)
        form_layout.addWidget(self.name_in, 0, 1)
        form_layout.addWidget(QLabel("Email:"), 1, 0)
        form_layout.addWidget(self.email_in, 1, 1)
        form_layout.addWidget(QLabel("Password:"), 2, 0)
        form_layout.addWidget(self.password_in, 2, 1)
        form_layout.addWidget(QLabel("Confirm:"), 3, 0)
        form_layout.addWidget(self.confirm_password_in, 3, 1)

        auth_box.setLayout(form_layout)
        auth_box.setTitle("Registration Details")

        layout.addWidget(auth_box, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(signup_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(login_lbl, alignment=Qt.AlignmentFlag.AlignCenter)

        for widget in [self.name_in, self.email_in, self.password_in, self.confirm_password_in]:
            widget.setMinimumWidth(300)

    def handle_signup(self):
        name = self.name_in.text().strip()
        email = self.email_in.text().strip()
        password = self.password_in.text()
        confirm_password = self.confirm_password_in.text()

        if not (name and email and password and confirm_password):
            QMessageBox.warning(self, "Error", "Please fill in all fields.")
            return

        email_pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        if not re.match(email_pattern, email):
            QMessageBox.warning(self, "Invalid Email",
                                "Please enter a valid email address.\nExample: russeljohnlasapragadio@gmail.com")
            self.email_in.setFocus()
            return

        if len(password) < 8:
            QMessageBox.warning(self, "Weak Password", "Password must be at least 8 characters long.")
            self.password_in.clear()
            self.confirm_password_in.clear()
            self.password_in.setFocus()
            return

        if password != confirm_password:
            QMessageBox.warning(self, "Error", "Passwords do not match.")
            self.password_in.clear()
            self.confirm_password_in.clear()
            return

        result = self.manager.register(name, email, password)

        if result is True:
            QMessageBox.information(self, "Success", "Registration successful! You can now log in.")
            self.login_requested.emit()
            self.name_in.clear()
            self.email_in.clear()
            self.password_in.clear()
            self.confirm_password_in.clear()
        elif "Email already registered." in result:
            QMessageBox.warning(self, "Error", "This email is already registered. Please log in.")
        else:
            QMessageBox.critical(self, "Error", f"Registration failed: {result}")


class AuthWidget(BaseWidget):
    customer_login_successful = pyqtSignal(str, str)
    admin_login_successful = pyqtSignal()

    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.stack = QStackedWidget()
        self.login_w = LoginWidget(manager)
        self.signup_w = SignupWidget(manager)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        logo = QLabel()
        pixmap = load_pixmap("ragadio logo", 150, 150)
        if pixmap.isNull():
            logo.setText("🚗")
            logo.setFont(QFont("Arial", 48))
        else:
            logo.setPixmap(pixmap)

        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet("margin-bottom: 20px; background-color: transparent;")

        header = self.create_label("Ragadio's Car Rentals", True, 20)
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.stack.addWidget(self.login_w)
        self.stack.addWidget(self.signup_w)

        self.login_w.register_requested.connect(lambda: self.stack.setCurrentWidget(self.signup_w))
        self.signup_w.login_requested.connect(lambda: self.stack.setCurrentWidget(self.login_w))

        self.login_w.customer_login_successful.connect(self.customer_login_successful.emit)
        self.login_w.admin_login_successful.connect(self.admin_login_successful.emit)

        layout.addWidget(header, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.stack, alignment=Qt.AlignmentFlag.AlignCenter)

    def reset_view(self):
        self.stack.setCurrentWidget(self.login_w)
        self.login_w.email_in.clear()
        self.login_w.password_in.clear()
        self.signup_w.name_in.clear()
        self.signup_w.email_in.clear()
        self.signup_w.password_in.clear()
        self.signup_w.confirm_password_in.clear()


# --- 3. Customer Widgets (Grid Layout) ---

class CarCard(QWidget):
    toggled = pyqtSignal(object, bool)

    def __init__(self, car):
        super().__init__()
        self.car = car
        self.is_checked = False
        self.setFixedSize(320, 420)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # 1. Image Area
        self.img_lbl = QLabel()
        self.img_lbl.setFixedSize(290, 180)
        self.img_lbl.setStyleSheet("background-color: #222; border-radius: 6px; border: 1px solid #333;")
        self.img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        pix = load_car_pixmap(self.car.image_path, 290, 180)
        self.img_lbl.setPixmap(pix)
        layout.addWidget(self.img_lbl)

        # 2. Car Name
        name_lbl = QLabel(self.car.name)
        name_lbl.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        name_lbl.setStyleSheet("color: white; background: transparent;")
        name_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name_lbl.setWordWrap(True)
        layout.addWidget(name_lbl)

        # 3. Price
        price_lbl = QLabel(f"{format_peso(self.car.price_per_day)} / day")
        price_lbl.setFont(QFont("Arial", 12))
        price_lbl.setStyleSheet("color: #0078d4; font-weight: bold; background: transparent;")
        price_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(price_lbl)

        # 4. Divider
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("background-color: #333; max-height: 1px;")
        layout.addWidget(line)

        # 5. Status
        qty_val = self.car.quantity if self.car.quantity is not None else 0
        status_text = f"✔ {qty_val} Available" if qty_val > 0 else "❌ Sold Out"
        status_color = "#27ae60" if qty_val > 0 else "#e74c3c"

        status_lbl = QLabel(status_text)
        status_lbl.setStyleSheet(f"color: {status_color}; font-size: 11px; font-weight: bold; background: transparent;")
        status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(status_lbl)

        layout.addStretch()

        # 6. Button
        self.select_btn = QPushButton("Select Vehicle")
        self.select_btn.setFixedHeight(35)
        self.select_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.select_btn.clicked.connect(self.handle_click)
        layout.addWidget(self.select_btn)

        self.update_style(False)

    def mousePressEvent(self, event):
        self.handle_click()

    def handle_click(self):
        qty_val = self.car.quantity if self.car.quantity is not None else 0
        if qty_val > 0:
            self.set_checked(not self.is_checked)
            self.toggled.emit(self, self.is_checked)
        else:
            QMessageBox.warning(self, "Unavailable", "This vehicle is currently sold out.")

    def set_checked(self, state):
        self.is_checked = state
        self.update_style(state)

    def update_style(self, is_checked):
        if is_checked:
            self.setStyleSheet("""
                CarCard { background-color: #2b2b2b; border: 2px solid #0078d4; border-radius: 12px; }
            """)
            self.select_btn.setText("Selected ✔")
            self.select_btn.setStyleSheet(
                "QPushButton { background-color: #0078d4; color: white; font-weight: bold; border-radius: 4px; border: none; }")
        else:
            self.setStyleSheet("""
                CarCard { background-color: #1e1e1e; border: 1px solid #333; border-radius: 12px; }
                CarCard:hover { background-color: #252526; border: 1px solid #555; }
            """)
            self.select_btn.setText("Select Vehicle")
            self.select_btn.setStyleSheet(
                "QPushButton { background-color: transparent; border: 1px solid #555; color: #ccc; border-radius: 4px; } QPushButton:hover { background-color: #333; color: white; border-color: #888; }")


class VehicleListWidget(BaseWidget):
    proceed_requested = pyqtSignal(object)

    def __init__(self, rental_manager):
        super().__init__()
        self.manager = rental_manager
        self.car_rows = []
        self.current_filter_id = None
        self.setup_ui()
        # Initial load (Safe because we use the swap method now)
        self.update_car_list(None)

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 30, 30, 30)

        self.welcome_lbl = self.create_label("", True, 24)
        self.welcome_lbl.setStyleSheet("color: white; margin-bottom: 5px;")
        main_layout.addWidget(self.welcome_lbl)

        self.subtitle = QLabel("Select a vehicle to continue:")
        self.subtitle.setStyleSheet("color: #888; font-size: 14px; margin-bottom: 20px;")
        main_layout.addWidget(self.subtitle)

        # Scroll Area setup
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { width: 10px; background: #222; margin: 0px; }
            QScrollBar::handle:vertical { background: #555; border-radius: 5px; }
        """)

        # We do NOT create self.cars_content_widget here anymore.
        # It will be created dynamically in update_car_list.

        main_layout.addWidget(self.scroll_area)

        self.proceed_btn = QPushButton("Proceed to Options")
        self.proceed_btn.setFixedHeight(55)
        self.proceed_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.proceed_btn.setStyleSheet("""
            QPushButton { background-color: #0078d4; color: white; font-weight: bold; font-size: 16px; border-radius: 8px; }
            QPushButton:hover { background-color: #005a9e; }
            QPushButton:disabled { background-color: #444; color: #888; }
        """)
        self.proceed_btn.clicked.connect(self.proceed_to_options)
        main_layout.addWidget(self.proceed_btn)

    def handle_row_toggle(self, clicked_card, is_checked):
        if is_checked:
            for card in self.car_rows:
                if card is not clicked_card:
                    card.set_checked(False)

    def update_car_list(self, filter_id=None):
        self.current_filter_id = filter_id
        self.car_rows.clear()  # Reset the tracking list

        # --- NUCLEAR FIX: CREATE A FRESH WIDGET EVERY TIME ---
        # Instead of deleting items from a layout (which causes the crash),
        # we create a brand new widget and swap it into the scroll area.
        # The old widget is automatically deleted by Python's garbage collector.

        new_content_widget = QWidget()
        new_content_widget.setStyleSheet("background: transparent;")
        new_layout = QVBoxLayout(new_content_widget)
        new_layout.setSpacing(30)
        new_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        try:
            categories = self.manager.get_categories()
        except:
            categories = []  # Handle DB failure gracefully

        for cat in categories:
            if filter_id is not None and str(cat['id']) != str(filter_id):
                continue

            cars = self.manager.get_cars(cat['id'])

            # Filter only available cars with stock > 0
            available_cars = [c for c in cars if c.quantity > 0]

            if not available_cars:
                continue

            # Category Header
            cat_lbl = QLabel(cat['name'].upper())
            cat_lbl.setStyleSheet(
                "color: #888; font-weight: bold; font-size: 14px; margin-bottom: 10px; border-bottom: 1px solid #333; padding-bottom: 5px;")
            new_layout.addWidget(cat_lbl)

            # Grid Container
            grid_container = QWidget()
            grid_layout = QGridLayout(grid_container)
            grid_layout.setSpacing(20)
            grid_layout.setContentsMargins(0, 0, 0, 0)
            grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

            row, col = 0, 0
            max_cols = 3

            for car in available_cars:
                card = CarCard(car)
                card.toggled.connect(self.handle_row_toggle)
                grid_layout.addWidget(card, row, col)
                self.car_rows.append(card)

                col += 1
                if col >= max_cols:
                    col = 0
                    row += 1

            new_layout.addWidget(grid_container)

        new_layout.addStretch(1)

        # SWAP THE WIDGET
        # This single line replaces the entire list safely without recursion or loop errors.
        self.scroll_area.setWidget(new_content_widget)

    def update_welcome_message(self, name):
        self.welcome_lbl.setText(f"Welcome, {name}!")

    def proceed_to_options(self):
        selected_car = None
        for card in self.car_rows:
            if card.is_checked:
                selected_car = card.car
                break

        if selected_car:
            # FIX: Signal delay to prevent stack overlap crash
            QTimer.singleShot(150, lambda: self.proceed_requested.emit(selected_car))
        else:
            QMessageBox.warning(self, "Selection Required", "Please select a vehicle first.")


class ServiceListItem(QWidget):
    def __init__(self, service_data):
        super().__init__()
        self.service_data = service_data
        self.is_checked = False
        self.setFixedHeight(55)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setup_ui()

    def setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 5, 15, 5)
        layout.setSpacing(15)

        self.checkbox_display = QLabel()
        self.checkbox_display.setFixedSize(20, 20)
        self.checkbox_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.checkbox_display.setStyleSheet("background: transparent; border: 2px solid #777; border-radius: 3px;")
        layout.addWidget(self.checkbox_display)

        name_lbl = QLabel(self.service_data['name'])
        name_lbl.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        name_lbl.setStyleSheet("color: white; background: transparent; border: none;")
        layout.addWidget(name_lbl)

        layout.addStretch()

        price_val = self.service_data['price']
        is_daily = bool(self.service_data['is_daily'])
        price_str = f"{format_peso(price_val)} / day" if is_daily else format_peso(price_val)

        self.price_lbl = QLabel(price_str)
        self.price_lbl.setFont(QFont("Arial", 10))
        self.price_lbl.setStyleSheet("color: #aaa; background: transparent; border: none;")
        layout.addWidget(self.price_lbl)

        self.update_style(False)

    def mousePressEvent(self, event):
        self.is_checked = not self.is_checked
        self.update_style(self.is_checked)

    def update_style(self, checked):
        if checked:
            self.setStyleSheet(
                "ServiceListItem { background-color: #2b2b2b; border: 1px solid #0078d4; border-radius: 4px; }")
            self.checkbox_display.setText("✔")
            self.checkbox_display.setStyleSheet(
                "background-color: #0078d4; color: white; border: none; border-radius: 3px; font-weight: bold;")
            self.price_lbl.setStyleSheet("color: #4caf50; background: transparent; border: none;")
        else:
            self.setStyleSheet(
                "ServiceListItem { background-color: #1e1e1e; border: 1px solid #333; border-radius: 4px; } ServiceListItem:hover { background-color: #252525; }")
            self.checkbox_display.setText("")
            self.checkbox_display.setStyleSheet("background: transparent; border: 2px solid #777; border-radius: 3px;")
            self.price_lbl.setStyleSheet("color: #aaa; background: transparent; border: none;")

class VehicleListWidget(BaseWidget):
    proceed_requested = pyqtSignal(object)

    def __init__(self, rental_manager):
        super().__init__() # <--- Ensure this is EMPTY
        self.manager = rental_manager
        self.all_car_cards = []
        self.car_rows = []
        self.current_filter_id = None

        # Default sort
        self.current_sort_key = 'name'
        self.current_sort_order = 'asc'

        self.search_input = QLineEdit()

        self.setup_ui()
        self.update_car_list(None)

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 30, 30, 30)

        # --- WELCOME LABEL ---
        self.welcome_lbl = QLabel("")
        self.welcome_lbl.setStyleSheet("""
            QLabel {
                font-family: 'Segoe UI', sans-serif;
                font-size: 28px;
                font-weight: bold;
                color: white;
                margin-bottom: 5px;
            }
        """)
        main_layout.addWidget(self.welcome_lbl)

        # --- Header with Sort & Search ---
        header_layout = QHBoxLayout()

        self.subtitle = QLabel("Select a vehicle to continue:")
        self.subtitle.setStyleSheet("""
            QLabel {
                font-family: 'Segoe UI', sans-serif;
                font-size: 16px;
                color: #888;
                margin-bottom: 15px;
            }
        """)
        header_layout.addWidget(self.subtitle)

        header_layout.addStretch()

        # Sorting ComboBox
        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Default (Name)", {"key": "name", "order": "asc"})
        self.sort_combo.addItem("Price: Low to High", {"key": "price_per_day", "order": "asc"})
        self.sort_combo.addItem("Price: High to Low", {"key": "price_per_day", "order": "desc"})
        self.sort_combo.addItem("Most Popular (Rented)", {"key": "rental_count", "order": "desc"})

        self.sort_combo.setFixedWidth(200)
        self.sort_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sort_combo.setStyleSheet("""
            QComboBox { 
                background-color: #252526; 
                border: 1px solid #555; 
                border-radius: 6px; 
                padding: 8px; 
                color: white; 
                font-size: 13px;
            } 
            QComboBox::drop-down { border: none; } 
            QComboBox QAbstractItemView { 
                background-color: #252526; 
                selection-background-color: #0078d4; 
                color: white; 
            }
        """)

        self.sort_combo.currentIndexChanged.connect(self.handle_sort_change)

        header_layout.addWidget(self.sort_combo)
        header_layout.addSpacing(15)

        # Search Bar
        self.search_input.setPlaceholderText("🔍 Search Car Model...")
        self.search_input.setFixedWidth(300)
        self.search_input.setStyleSheet("""
            QLineEdit { 
                background-color: #252526; 
                border: 1px solid #555; 
                border-radius: 6px; 
                padding: 8px; 
                color: white; 
                font-size: 13px;
            }
        """)
        self.search_input.textChanged.connect(self.filter_car_list)
        header_layout.addWidget(self.search_input)

        main_layout.addLayout(header_layout)

        # Scroll Area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { width: 10px; background: #222; margin: 0px; }
            QScrollBar::handle:vertical { background: #555; border-radius: 5px; }
        """)

        main_layout.addWidget(self.scroll_area)

        self.proceed_btn = QPushButton("Proceed to Options")
        self.proceed_btn.setFixedHeight(60)
        self.proceed_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.proceed_btn.setStyleSheet("""
            QPushButton { 
                background-color: #0078d4; 
                color: white; 
                font-weight: bold; 
                font-size: 18px; 
                border-radius: 8px; 
            }
            QPushButton:hover { background-color: #005a9e; }
            QPushButton:disabled { background-color: #444; color: #888; }
        """)
        self.proceed_btn.clicked.connect(self.proceed_to_options)
        main_layout.addWidget(self.proceed_btn)

    def handle_sort_change(self, index):
        sort_data = self.sort_combo.currentData()
        if sort_data:
            self.current_sort_key = sort_data['key']
            self.current_sort_order = sort_data['order']
            self.update_car_list(self.current_filter_id)

    def handle_row_toggle(self, clicked_card, is_checked):
        if is_checked:
            for card in self.car_rows:
                if card is not clicked_card and card.isVisible():
                    card.set_checked(False)

    def update_car_list(self, filter_id=None):
        self.current_filter_id = filter_id
        self.all_car_cards.clear()

        new_content_widget = QWidget()
        new_content_widget.setStyleSheet("background: transparent;")
        new_layout = QVBoxLayout(new_content_widget)
        new_layout.setSpacing(30)
        new_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # Pre-calculate rental counts
        rental_counts = {}
        if self.current_sort_key == 'rental_count':
            try:
                txns = self.manager.get_all_transactions()
                for t in txns:
                    name = t.car.name
                    rental_counts[name] = rental_counts.get(name, 0) + 1
            except:
                pass

        try:
            categories = self.manager.get_categories()
        except:
            categories = []

        for cat in categories:
            if filter_id is not None and str(cat['id']) != str(filter_id):
                continue

            cars = self.manager.get_cars(cat['id'])
            available_cars = [c for c in cars if c.quantity > 0]

            if not available_cars:
                continue

            # Sort
            reverse_sort = (self.current_sort_order == 'desc')
            if self.current_sort_key == 'rental_count':
                available_cars.sort(key=lambda c: rental_counts.get(c.name, 0), reverse=True)
            else:
                available_cars.sort(key=lambda c: getattr(c, self.current_sort_key), reverse=reverse_sort)

            # Category Header
            cat_lbl = QLabel(cat['name'].upper())
            cat_lbl.setStyleSheet("""
                color: #888; 
                font-weight: bold; 
                font-size: 14px; 
                margin-bottom: 10px; 
                border-bottom: 1px solid #333; 
                padding-bottom: 5px;
                font-family: 'Segoe UI', sans-serif;
            """)
            cat_lbl.setProperty("category_header", True)
            new_layout.addWidget(cat_lbl)

            # Grid
            grid_container = QWidget()
            grid_layout = QGridLayout(grid_container)
            grid_layout.setSpacing(20)
            grid_layout.setContentsMargins(0, 0, 0, 0)
            grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

            row_idx, col_idx = 0, 0
            max_cols = 3

            for car in available_cars:
                card = CarCard(car)
                card.toggled.connect(self.handle_row_toggle)
                grid_layout.addWidget(card, row_idx, col_idx)
                self.all_car_cards.append(card)

                col_idx += 1
                if col_idx >= max_cols:
                    col_idx = 0
                    row_idx += 1

            new_layout.addWidget(grid_container)

        new_layout.addStretch(1)
        self.scroll_area.setWidget(new_content_widget)
        self.filter_car_list(self.search_input.text())

    def filter_car_list(self, search_text):
        search_text = search_text.strip().lower()
        self.car_rows.clear()

        for card in self.all_car_cards:
            car_name = card.car.name.lower()
            if search_text in car_name:
                card.show()
                self.car_rows.append(card)
            else:
                card.hide()
                card.set_checked(False)

    def update_welcome_message(self, name):
        self.welcome_lbl.setText(f"Welcome, {name}!")

    def proceed_to_options(self):
        selected_car = None
        for card in self.car_rows:
            if card.is_checked:
                selected_car = card.car
                break

        if selected_car:
            QTimer.singleShot(150, lambda: self.proceed_requested.emit(selected_car))
        else:
            QMessageBox.warning(self, "Selection Required", "Please select a vehicle first.")


class MessagesTab(BaseWidget):
    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.current_tickets = []
        self.current_chats = []
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # --- Header ---
        header_layout = QHBoxLayout()
        header_layout.addWidget(self.create_label("Help Desk & Inquiries", True, 18))
        header_layout.addStretch()

        # --- NEW: FILTER DROPDOWN ---
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["Show All History", "🔴 Open / New Only", "✅ Replied / Done Only"])
        self.filter_combo.setFixedWidth(180)
        self.filter_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.filter_combo.setStyleSheet("""
            QComboBox { 
                background-color: #252526; 
                border: 1px solid #555; 
                border-radius: 4px; 
                padding: 6px; 
                color: white; 
                font-weight: bold;
            }
            QComboBox::drop-down { border: none; }
            QComboBox QAbstractItemView { 
                background-color: #252526; 
                selection-background-color: #0078d4; 
                color: white; 
            }
        """)
        self.filter_combo.currentIndexChanged.connect(self.populate_message_table)
        header_layout.addWidget(self.filter_combo)

        header_layout.addSpacing(10)

        # Refresh Button
        refresh_btn = QPushButton("Refresh Data")
        refresh_btn.setFixedWidth(120)
        refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        refresh_btn.clicked.connect(self.populate_message_table)
        refresh_btn.setStyleSheet("""
            QPushButton { background-color: #555; color: white; border-radius: 4px; padding: 6px; font-weight: bold; } 
            QPushButton:hover { background-color: #666; }
        """)
        header_layout.addWidget(refresh_btn)
        layout.addLayout(header_layout)

        # --- TABS ---
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #444; background: #1e1e1e; }
            QTabBar::tab { background: #2d2d2d; color: #aaa; padding: 10px 20px; font-weight: bold; border-top-left-radius: 4px; border-top-right-radius: 4px; margin-right: 2px; }
            QTabBar::tab:selected { background: #0078d4; color: white; }
            QTabBar::tab:hover { background: #3a3a3a; color: white; }
        """)

        self.ticket_tab = QWidget()
        self.chat_tab = QWidget()

        self.tabs.addTab(self.ticket_tab, "⚠ Priority Tickets")
        self.tabs.addTab(self.chat_tab, "💬 General Messages")

        layout.addWidget(self.tabs)

        self.setup_ticket_tab()
        self.setup_chat_tab()

        # Initial Load
        self.populate_message_table()

    def setup_ticket_tab(self):
        layout = QVBoxLayout(self.ticket_tab)
        layout.setContentsMargins(10, 15, 10, 10)

        info = QLabel("Priority Queue: Oldest 'Open' tickets appear at the top.")
        info.setStyleSheet("color: #888; font-style: italic; margin-bottom: 5px;")
        layout.addWidget(info)

        self.ticket_table = QTableWidget()
        self.ticket_table.setColumnCount(7)
        self.ticket_table.setHorizontalHeaderLabels(
            ["Priority", "Date", "Customer", "Issue Snippet", "Status", "Wait Time", "Action"])

        self.configure_table(self.ticket_table)
        self.ticket_table.cellDoubleClicked.connect(self.on_ticket_row_activated)

        # Column sizing
        h = self.ticket_table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self.ticket_table.setColumnWidth(0, 80)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        self.ticket_table.setColumnWidth(2, 130)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
        self.ticket_table.setColumnWidth(4, 90)
        h.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(6, QHeaderView.ResizeMode.Fixed)
        self.ticket_table.setColumnWidth(6, 140)

        layout.addWidget(self.ticket_table)

    def setup_chat_tab(self):
        layout = QVBoxLayout(self.chat_tab)
        layout.setContentsMargins(10, 15, 10, 10)

        self.chat_table = QTableWidget()
        self.chat_table.setColumnCount(6)
        self.chat_table.setHorizontalHeaderLabels(
            ["Date", "Customer", "Message Snippet", "Status", "Reply Date", "Action"])

        self.configure_table(self.chat_table)
        self.chat_table.cellDoubleClicked.connect(self.on_chat_row_activated)

        # Column sizing
        h = self.chat_table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.chat_table.setColumnWidth(1, 130)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.chat_table.setColumnWidth(3, 90)
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(5, QHeaderView.ResizeMode.Fixed)
        self.chat_table.setColumnWidth(5, 140)

        layout.addWidget(self.chat_table)

    def configure_table(self, table):
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setDefaultSectionSize(40)
        table.setStyleSheet("""
            QTableWidget { background-color: #1e1e1e; alternate-background-color: #252526; border: 1px solid #444; gridline-color: #444; color: #ddd; }
            QHeaderView::section { background-color: #2d2d2d; padding: 4px; border: 1px solid #333; font-weight: bold; color: #eee; }
            QTableWidget::item { padding: 0 5px; border: none; }
        """)

    def populate_message_table(self):
        all_msgs = self.manager.get_all_messages()

        # Separate buckets
        tickets_open = []
        tickets_replied = []
        chats_new = []
        chats_replied = []

        for msg in all_msgs:
            raw_text = msg['message_text']
            is_ticket = raw_text.startswith("[TICKET]")
            has_reply = bool(msg.get('admin_reply'))

            if is_ticket:
                if has_reply:
                    tickets_replied.append(msg)
                else:
                    tickets_open.append(msg)
            else:
                if has_reply:
                    chats_replied.append(msg)
                else:
                    chats_new.append(msg)

        # Sort Buckets
        tickets_open.sort(key=lambda x: x['timestamp'])  # Oldest Open first
        tickets_replied.sort(key=lambda x: x['timestamp'], reverse=True)  # Newest Replied first
        chats_new.sort(key=lambda x: x['timestamp'], reverse=True)
        chats_replied.sort(key=lambda x: x['timestamp'], reverse=True)

        # --- APPLY FILTER ---
        filter_idx = self.filter_combo.currentIndex()  # 0=All, 1=Open Only, 2=Replied Only

        if filter_idx == 1:  # Open/New Only
            self.current_tickets = tickets_open
            self.current_chats = chats_new
        elif filter_idx == 2:  # Replied Only
            self.current_tickets = tickets_replied
            self.current_chats = chats_replied
        else:  # Show All
            self.current_tickets = tickets_open + tickets_replied
            self.current_chats = chats_new + chats_replied

        # --- RENDER TICKETS ---
        self.ticket_table.setRowCount(len(self.current_tickets))
        for row, msg in enumerate(self.current_tickets):
            has_reply = bool(msg.get('admin_reply'))

            if not has_reply:
                prio_item = QTableWidgetItem(f"#{row + 1}")
                prio_item.setForeground(QColor("#e74c3c"))
                prio_item.setFont(QFont("Arial", 10, QFont.Weight.Bold))
            else:
                prio_item = QTableWidgetItem("Done")
                prio_item.setForeground(QColor("#2ecc71"))

            prio_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.ticket_table.setItem(row, 0, prio_item)

            date_str = msg['timestamp'].strftime("%Y-%m-%d") if msg['timestamp'] else "-"
            self.ticket_table.setItem(row, 1, QTableWidgetItem(date_str))
            self.ticket_table.setItem(row, 2, QTableWidgetItem(msg['user_name']))

            clean_text = msg['message_text'].replace("[TICKET]", "").strip().replace('\n', ' ')
            self.ticket_table.setItem(row, 3, QTableWidgetItem(clean_text))

            status_text = "Replied" if has_reply else "OPEN"
            status_color = QColor("#2ecc71") if has_reply else QColor("#e74c3c")
            status_item = QTableWidgetItem(status_text)
            status_item.setForeground(status_color)
            status_item.setFont(QFont("Arial", 9, QFont.Weight.Bold))
            status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.ticket_table.setItem(row, 4, status_item)

            if not has_reply and msg['timestamp']:
                delta = datetime.datetime.now() - msg['timestamp']
                if delta.days > 0:
                    wait_str = f"{delta.days} days"
                else:
                    wait_str = f"{delta.seconds // 3600} hrs"
                wait_item = QTableWidgetItem(wait_str)
                wait_item.setForeground(QColor("#e67e22"))
            else:
                wait_item = QTableWidgetItem("-")

            wait_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.ticket_table.setItem(row, 5, wait_item)

            self.add_action_btn(self.ticket_table, row, msg, has_reply)

        # --- RENDER CHATS ---
        self.chat_table.setRowCount(len(self.current_chats))
        for row, msg in enumerate(self.current_chats):
            has_reply = bool(msg.get('admin_reply'))

            date_str = msg['timestamp'].strftime("%Y-%m-%d") if msg['timestamp'] else "-"
            self.chat_table.setItem(row, 0, QTableWidgetItem(date_str))
            self.chat_table.setItem(row, 1, QTableWidgetItem(msg['user_name']))

            clean_text = msg['message_text'].replace('\n', ' ')
            self.chat_table.setItem(row, 2, QTableWidgetItem(clean_text))

            status_text = "Replied" if has_reply else "New"
            status_color = QColor("#2ecc71") if has_reply else QColor("#3498db")
            status_item = QTableWidgetItem(status_text)
            status_item.setForeground(status_color)
            status_item.setFont(QFont("Arial", 9, QFont.Weight.Bold))
            status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.chat_table.setItem(row, 3, status_item)

            reply_date = "Today" if has_reply else "-"
            reply_item = QTableWidgetItem(reply_date)
            reply_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.chat_table.setItem(row, 4, reply_item)

            self.add_action_btn(self.chat_table, row, msg, has_reply)

    def add_action_btn(self, table, row, msg, has_reply):
        btn_widget = QWidget()
        btn_layout = QHBoxLayout(btn_widget)
        btn_layout.setContentsMargins(4, 4, 4, 4)
        btn_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        reply_btn = QPushButton("View / Reply" if has_reply else "Reply")
        reply_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        reply_btn.setFixedHeight(26)

        bg_color = '#27ae60' if has_reply else '#0078d4'
        hover_color = '#219150' if has_reply else '#005a9e'

        reply_btn.setStyleSheet(f"""
            QPushButton {{ background-color: {bg_color}; color: white; border-radius: 3px; padding: 0 10px; font-weight: bold; font-size: 11px; }}
            QPushButton:hover {{ background-color: {hover_color}; }}
        """)
        reply_btn.clicked.connect(lambda _, m=msg: self.handle_reply(m))
        btn_layout.addWidget(reply_btn)
        table.setCellWidget(row, table.columnCount() - 1, btn_widget)

    def on_ticket_row_activated(self, row, col):
        if 0 <= row < len(self.current_tickets):
            self.handle_reply(self.current_tickets[row])

    def on_chat_row_activated(self, row, col):
        if 0 <= row < len(self.current_chats):
            self.handle_reply(self.current_chats[row])

    def handle_reply(self, message_data):
        dialog = ReplyDialog(message_data, self)
        if dialog.exec():
            reply_text = dialog.reply_text
            msg_id = message_data.get('id')
            if msg_id:
                result = self.manager.send_reply(msg_id, reply_text)
                if result is True:
                    QMessageBox.information(self, "Sent", "Reply saved successfully.")
                    self.populate_message_table()

class ReceiptWidget(BaseWidget):
    start_new_rental = pyqtSignal()
    cancel_requested = pyqtSignal(dict)  # <--- CRITICAL FIX: ADD THIS LINE

    def __init__(self):
        super().__init__()
        self.current_data = None  # Store data for the PDF
        self.user_name = ""
        self.setup_ui()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.setContentsMargins(20, 20, 20, 20)

        self.receipt_card = QWidget()
        self.receipt_card.setFixedWidth(480)
        self.receipt_card.setStyleSheet("""
            QWidget {
                background-color: #252526;
                border: 1px solid #333;
                border-radius: 12px;
            }
            QLabel {
                border: none;
                background: transparent;
            }
        """)

        card_layout = QVBoxLayout(self.receipt_card)
        card_layout.setSpacing(10)
        card_layout.setContentsMargins(30, 40, 30, 40)

        self.logo_lbl = QLabel("RAGADIO RENTALS")
        self.logo_lbl.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        self.logo_lbl.setStyleSheet("color: white; letter-spacing: 1px;")
        self.logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(self.logo_lbl)

        subtitle = QLabel("OFFICIAL RECEIPT")
        subtitle.setStyleSheet("color: #666; font-size: 10px; letter-spacing: 3px; font-weight: bold;")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(subtitle)

        self.add_separator(card_layout)

        info_grid = QGridLayout()
        info_grid.setVerticalSpacing(5)

        info_grid.addWidget(self.create_label("Client:", False, 10, "#888"), 0, 0)
        self.client_name_lbl = self.create_label("Name", True, 11, "white")
        self.client_name_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
        info_grid.addWidget(self.client_name_lbl, 0, 1)

        info_grid.addWidget(self.create_label("Date:", False, 10, "#888"), 1, 0)
        self.date_lbl = self.create_label("", True, 11, "white")
        self.date_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
        info_grid.addWidget(self.date_lbl, 1, 1)

        card_layout.addLayout(info_grid)

        self.add_separator(card_layout)

        self.items_layout = QVBoxLayout()
        self.items_layout.setSpacing(8)
        card_layout.addLayout(self.items_layout)

        card_layout.addStretch()

        self.add_separator(card_layout)

        total_layout = QHBoxLayout()
        total_lbl = QLabel("TOTAL PAID")
        total_lbl.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        total_lbl.setStyleSheet("color: #ccc;")

        self.final_total_lbl = QLabel("P 0.00")
        self.final_total_lbl.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        self.final_total_lbl.setStyleSheet("color: #4caf50;")
        self.final_total_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)

        total_layout.addWidget(total_lbl)
        total_layout.addWidget(self.final_total_lbl)
        card_layout.addLayout(total_layout)

        footer = QLabel("Thank you for your booking!")
        footer.setStyleSheet("color: #555; font-style: italic; font-size: 11px; margin-top: 15px;")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(footer)

        main_layout.addWidget(self.receipt_card)

        # --- NEW BUTTONS ROW (WITH CANCEL) ---
        btn_row = QHBoxLayout()

        # 1. Cancel Button (NEW)
        self.cancel_btn = QPushButton("❌ Cancel Booking")
        self.cancel_btn.setFixedSize(160, 45)
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn.setStyleSheet("""
            QPushButton { background-color: #c0392b; color: white; border-radius: 5px; font-weight: bold; }
            QPushButton:hover { background-color: #a0291b; }
        """)
        self.cancel_btn.clicked.connect(self._handle_cancel_click)

        # 2. Print Button
        self.print_btn = QPushButton("📄 Save Invoice (PDF)")
        self.print_btn.setFixedSize(160, 45)
        self.print_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.print_btn.setStyleSheet("""
            QPushButton { background-color: #e67e22; color: white; border-radius: 5px; font-weight: bold; }
            QPushButton:hover { background-color: #d35400; }
        """)
        self.print_btn.clicked.connect(self.handle_save_pdf)

        # 3. New Rental Button
        self.new_rental_btn = QPushButton("Done / New Rental")
        self.new_rental_btn.setFixedSize(160, 45)
        self.new_rental_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.new_rental_btn.setStyleSheet("""
            QPushButton { background-color: #0078d4; color: white; border-radius: 5px; font-weight: bold; }
            QPushButton:hover { background-color: #005a9e; }
        """)

        # FIX: Added delay to New Rental button to prevent crash
        self.new_rental_btn.clicked.connect(lambda: QTimer.singleShot(150, self.start_new_rental.emit))

        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.print_btn)
        btn_row.addWidget(self.new_rental_btn)
        main_layout.addLayout(btn_row)

    def _handle_cancel_click(self):
        # Confirmation dialog before sending the cancel signal
        reply = QMessageBox.question(self, "Confirm Cancellation",
                                     "Are you sure you want to cancel this booking?\nThis will revert car stock.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            # We must emit the current data (including car name/ID) to app.py
            # FIX: We need to ensure current_data is valid before emitting
            if self.current_data and self.current_data.get('car'):
                # Delay the signal to prevent crash
                QTimer.singleShot(150, lambda: self.cancel_requested.emit(self.current_data))
            else:
                QMessageBox.critical(self, "Error", "Cannot cancel: Booking data is missing.")

    def create_label(self, text, bold=False, size=12, color="#ccc"):
        lbl = QLabel(text)
        font = QFont("Arial", size)
        if bold: font.setBold(True)
        lbl.setFont(font)
        lbl.setStyleSheet(f"color: {color}; background: transparent;")
        return lbl

    def add_separator(self, layout):
        line = QLabel()
        line.setFixedHeight(1)
        line.setStyleSheet("background-color: #333; margin-top: 5px; margin-bottom: 5px;")
        layout.addWidget(line)

    def add_line_item(self, name, price, is_main=False):
        row = QHBoxLayout()
        name_lbl = QLabel(name)
        name_lbl.setFont(QFont("Arial", 11 if is_main else 10))
        if is_main:
            name_lbl.setStyleSheet("color: white; font-weight: bold;")
        else:
            name_lbl.setStyleSheet("color: #aaa;")

        price_lbl = QLabel(price)
        price_lbl.setFont(QFont("Arial", 11 if is_main else 10))
        if is_main:
            price_lbl.setStyleSheet("color: white; font-weight: bold;")
        else:
            price_lbl.setStyleSheet("color: #aaa;")
        price_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)

        row.addWidget(name_lbl)
        row.addWidget(price_lbl)
        self.items_layout.addLayout(row)

    def update_receipt(self, name, data):
        self.user_name = name
        self.current_data = data
        self.current_data['user_name'] = name
        self.current_data['user_email'] = self.current_data.get('user_email', 'N/A')

        self.client_name_lbl.setText(name)
        self.date_lbl.setText(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))

        while self.items_layout.count():
            item = self.items_layout.takeAt(0)
            if item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget(): child.widget().deleteLater()

        car_text = f"{data['car'].name} (x{data['duration']} Days)"
        self.add_line_item(car_text, format_peso(data["base_total"]), is_main=True)

        if data["services"]:
            for svc in data["services"]:
                self.add_line_item(f"+ {svc['name']}", format_peso(svc['cost']), is_main=False)

        self.final_total_lbl.setText(format_peso(data["final_total"]))

    def handle_save_pdf(self):
        if not self.current_data: return

        filename, _ = QFileDialog.getSaveFileName(self, "Save Invoice",
                                                  f"Invoice_{datetime.datetime.now().strftime('%Y%m%d')}.pdf",
                                                  "PDF Files (*.pdf)")

        if filename:
            try:
                if 'user_email' not in self.current_data:
                    self.current_data['user_email'] = "client@email.com"
                generate_invoice_pdf(filename, self.current_data)
                QMessageBox.information(self, "Success", "Invoice saved successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save PDF: {str(e)}")


class CustomerHistoryWidget(BaseWidget):
    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # --- Header ---
        header_layout = QHBoxLayout()

        title_container = QVBoxLayout()
        header_lbl = self.create_label("My Rental History", True, 24)
        header_lbl.setStyleSheet("color: white;")
        subtitle = QLabel("View your active and past transactions.")
        subtitle.setStyleSheet("color: #888; font-size: 14px;")
        title_container.addWidget(header_lbl)
        title_container.addWidget(subtitle)

        refresh_btn = QPushButton("Refresh List")
        refresh_btn.setFixedSize(120, 35)
        refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        refresh_btn.setStyleSheet("""
            QPushButton { background-color: #333; color: white; border: 1px solid #555; border-radius: 4px; }
            QPushButton:hover { background-color: #444; border-color: #777; }
        """)
        refresh_btn.clicked.connect(self.refresh_data)

        header_layout.addLayout(title_container)
        header_layout.addStretch()
        header_layout.addWidget(refresh_btn)
        layout.addLayout(header_layout)

        # --- Table ---
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["Date Rented", "Trans ID", "Car Model", "Duration", "Total Paid", "Status"])

        # Style the table
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.setAlternatingRowColors(True)
        self.table.setStyleSheet("""
            QTableWidget { 
                background-color: #1e1e1e; 
                alternate-background-color: #252526;
                border: 1px solid #333; 
                gridline-color: #444; 
                color: #ddd; 
            }
            QHeaderView::section { 
                background-color: #2d2d2d; 
                padding: 10px; 
                border: 1px solid #333; 
                font-weight: bold; 
                color: #eee; 
            }
            QTableWidget::item { 
                padding: 5px; 
                border: none; 
            }
        """)

        # Specific column widths
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)  # ID
        self.table.setColumnWidth(1, 80)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)  # Duration
        self.table.setColumnWidth(3, 100)

        layout.addWidget(self.table)

    def refresh_data(self):
        # Helper to refresh manually if needed
        user = self.manager.current_user
        if user and user.get('id'):
            self.populate_table(user['id'])

    def populate_table(self, user_id):
        # Fetch data from database
        txns = self.manager.get_transactions_by_user_id(user_id)
        self.table.setRowCount(len(txns))

        for row, tx in enumerate(txns):
            # 1. Date
            date_str = tx.timestamp.strftime("%Y-%m-%d") if tx.timestamp else "-"
            self.table.setItem(row, 0, QTableWidgetItem(date_str))

            # 2. Trans ID
            id_item = QTableWidgetItem(str(tx.id))
            id_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 1, id_item)

            # 3. Car
            self.table.setItem(row, 2, QTableWidgetItem(tx.car.name))

            # 4. Duration
            days_item = QTableWidgetItem(f"{tx.duration} Days")
            days_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 3, days_item)

            # 5. Total
            total_item = QTableWidgetItem(format_peso(tx.final_total))
            total_item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            self.table.setItem(row, 4, total_item)

            # 6. Status (Active/Returned)
            status_text = tx.status
            status_item = QTableWidgetItem(status_text)
            status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            status_item.setFont(QFont("Arial", 9, QFont.Weight.Bold))

            if status_text == "Active":
                status_item.setForeground(QColor("#2ecc71"))  # Green
            elif status_text == "Returned":
                status_item.setForeground(QColor("#3498db"))  # Blue
            else:
                status_item.setForeground(QColor("#e74c3c"))  # Red (if any error)

            self.table.setItem(row, 5, status_item)

class VehicleListWidget(BaseWidget):
    proceed_requested = pyqtSignal(object)

    def __init__(self, rental_manager):
        super().__init__()
        # FIX: Use 'rental_manager' to match the argument name above
        self.manager = rental_manager
        self.all_car_cards = []
        self.car_rows = []
        self.current_filter_id = None

        # Default sort
        self.current_sort_key = 'name'
        self.current_sort_order = 'asc'

        self.search_input = QLineEdit()

        self.setup_ui()
        self.update_car_list(None)

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 30, 30, 30)

        # --- WELCOME LABEL (28px Header) ---
        self.welcome_lbl = QLabel("")
        self.welcome_lbl.setStyleSheet("""
            QLabel {
                font-family: 'Segoe UI', sans-serif;
                font-size: 28px;
                font-weight: bold;
                color: white;
                margin-bottom: 5px;
            }
        """)
        main_layout.addWidget(self.welcome_lbl)

        # --- Header with Sort & Search ---
        header_layout = QHBoxLayout()

        self.subtitle = QLabel("Select a vehicle to continue:")
        self.subtitle.setStyleSheet("""
            QLabel {
                font-family: 'Segoe UI', sans-serif;
                font-size: 16px;
                color: #888;
                margin-bottom: 15px;
            }
        """)
        header_layout.addWidget(self.subtitle)

        header_layout.addStretch()

        # Sorting ComboBox
        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Default (Name)", {"key": "name", "order": "asc"})
        self.sort_combo.addItem("Price: Low to High", {"key": "price_per_day", "order": "asc"})
        self.sort_combo.addItem("Price: High to Low", {"key": "price_per_day", "order": "desc"})
        self.sort_combo.addItem("Most Popular (Rented)", {"key": "rental_count", "order": "desc"})

        self.sort_combo.setFixedWidth(200)
        self.sort_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sort_combo.setStyleSheet("""
            QComboBox { 
                background-color: #252526; 
                border: 1px solid #555; 
                border-radius: 6px; 
                padding: 8px; 
                color: white; 
                font-size: 13px;
            } 
            QComboBox::drop-down { border: none; } 
            QComboBox QAbstractItemView { 
                background-color: #252526; 
                selection-background-color: #0078d4; 
                color: white; 
            }
        """)

        self.sort_combo.currentIndexChanged.connect(self.handle_sort_change)

        header_layout.addWidget(self.sort_combo)
        header_layout.addSpacing(15)

        # Search Bar
        self.search_input.setPlaceholderText("🔍 Search Car Model...")
        self.search_input.setFixedWidth(300)
        self.search_input.setStyleSheet("""
            QLineEdit { 
                background-color: #252526; 
                border: 1px solid #555; 
                border-radius: 6px; 
                padding: 8px; 
                color: white; 
                font-size: 13px;
            }
        """)
        self.search_input.textChanged.connect(self.filter_car_list)
        header_layout.addWidget(self.search_input)

        main_layout.addLayout(header_layout)

        # Scroll Area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { width: 10px; background: #222; margin: 0px; }
            QScrollBar::handle:vertical { background: #555; border-radius: 5px; }
        """)

        main_layout.addWidget(self.scroll_area)

        self.proceed_btn = QPushButton("Proceed to Options")
        self.proceed_btn.setFixedHeight(60)
        self.proceed_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.proceed_btn.setStyleSheet("""
            QPushButton { 
                background-color: #0078d4; 
                color: white; 
                font-weight: bold; 
                font-size: 18px; 
                border-radius: 8px; 
            }
            QPushButton:hover { background-color: #005a9e; }
            QPushButton:disabled { background-color: #444; color: #888; }
        """)
        self.proceed_btn.clicked.connect(self.proceed_to_options)
        main_layout.addWidget(self.proceed_btn)

    def handle_sort_change(self, index):
        sort_data = self.sort_combo.currentData()
        if sort_data:
            self.current_sort_key = sort_data['key']
            self.current_sort_order = sort_data['order']
            self.update_car_list(self.current_filter_id)

    def handle_row_toggle(self, clicked_card, is_checked):
        if is_checked:
            for card in self.car_rows:
                if card is not clicked_card and card.isVisible():
                    card.set_checked(False)

    def update_car_list(self, filter_id=None):
        self.current_filter_id = filter_id
        self.all_car_cards.clear()

        new_content_widget = QWidget()
        new_content_widget.setStyleSheet("background: transparent;")
        new_layout = QVBoxLayout(new_content_widget)
        new_layout.setSpacing(30)
        new_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # Pre-calculate rental counts for sorting
        rental_counts = {}
        if self.current_sort_key == 'rental_count':
            try:
                txns = self.manager.get_all_transactions()
                for t in txns:
                    name = t.car.name
                    rental_counts[name] = rental_counts.get(name, 0) + 1
            except:
                pass

        try:
            categories = self.manager.get_categories()
        except:
            categories = []

        for cat in categories:
            if filter_id is not None and str(cat['id']) != str(filter_id):
                continue

            cars = self.manager.get_cars(cat['id'])
            available_cars = [c for c in cars if c.quantity > 0]

            if not available_cars:
                continue

            # Sort
            reverse_sort = (self.current_sort_order == 'desc')
            if self.current_sort_key == 'rental_count':
                available_cars.sort(key=lambda c: rental_counts.get(c.name, 0), reverse=True)
            else:
                available_cars.sort(key=lambda c: getattr(c, self.current_sort_key), reverse=reverse_sort)

            # Category Header
            cat_lbl = QLabel(cat['name'].upper())
            cat_lbl.setStyleSheet("""
                color: #888; 
                font-weight: bold; 
                font-size: 14px; 
                margin-bottom: 10px; 
                border-bottom: 1px solid #333; 
                padding-bottom: 5px;
                font-family: 'Segoe UI', sans-serif;
            """)
            cat_lbl.setProperty("category_header", True)
            new_layout.addWidget(cat_lbl)

            # Grid
            grid_container = QWidget()
            grid_layout = QGridLayout(grid_container)
            grid_layout.setSpacing(20)
            grid_layout.setContentsMargins(0, 0, 0, 0)
            grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

            row_idx, col_idx = 0, 0
            max_cols = 3

            for car in available_cars:
                card = CarCard(car)
                card.toggled.connect(self.handle_row_toggle)
                grid_layout.addWidget(card, row_idx, col_idx)
                self.all_car_cards.append(card)

                col_idx += 1
                if col_idx >= max_cols:
                    col_idx = 0
                    row_idx += 1

            new_layout.addWidget(grid_container)

        new_layout.addStretch(1)
        self.scroll_area.setWidget(new_content_widget)
        self.filter_car_list(self.search_input.text())

    def filter_car_list(self, search_text):
        search_text = search_text.strip().lower()
        self.car_rows.clear()

        for card in self.all_car_cards:
            car_name = card.car.name.lower()
            if search_text in car_name:
                card.show()
                self.car_rows.append(card)
            else:
                card.hide()
                card.set_checked(False)

    def update_welcome_message(self, name):
        self.welcome_lbl.setText(f"Welcome, {name}!")

    def proceed_to_options(self):
        selected_car = None
        for card in self.car_rows:
            if card.is_checked:
                selected_car = card.car
                break

        if selected_car:
            QTimer.singleShot(150, lambda: self.proceed_requested.emit(selected_car))
        else:
            QMessageBox.warning(self, "Selection Required", "Please select a vehicle first.")


class SidebarWidget(QWidget):
    vehicle_list_requested = pyqtSignal()
    message_center_requested = pyqtSignal()
    history_requested = pyqtSignal()
    logout_requested = pyqtSignal()
    category_selected = pyqtSignal(object)

    def __init__(self, manager=None):
        super().__init__()
        self.setFixedWidth(280)
        self.setObjectName("Sidebar")
        self.manager = manager
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- 1. Header / Logo Area ---
        header_container = QWidget()
        header_container.setFixedHeight(80)
        header_container.setStyleSheet("background-color: #1e1e1e; border-bottom: 1px solid #333;")
        header_layout = QVBoxLayout(header_container)
        header_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        logo = QLabel("RAGADIO RENTALS")
        logo.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        logo.setStyleSheet("color: #0078d4; letter-spacing: 1px;")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(logo)

        layout.addWidget(header_container)

        # --- Content Container ---
        content_container = QWidget()
        content_layout = QVBoxLayout(content_container)
        content_layout.setContentsMargins(15, 20, 15, 20)
        content_layout.setSpacing(15)

        # --- 2. User Profile Card ---
        self.profile_card = QWidget()
        self.profile_card.setStyleSheet("""
            QWidget {
                background-color: #252526;
                border: 1px solid #383838;
                border-radius: 8px;
            }
        """)
        profile_layout = QHBoxLayout(self.profile_card)
        profile_layout.setContentsMargins(20, 15, 20, 15)
        profile_layout.setSpacing(15)

        # Avatar
        avatar = QLabel("👤")
        avatar.setStyleSheet("font-size: 24px; border: none; background: transparent;")
        profile_layout.addWidget(avatar)

        # Text Details
        text_layout = QVBoxLayout()
        text_layout.setSpacing(2)
        text_layout.setContentsMargins(0, 0, 0, 0)

        self.username_lbl = QLabel("Guest")
        self.username_lbl.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        self.username_lbl.setStyleSheet("color: white; border: none; background: transparent;")

        self.userid_lbl = QLabel("ID: --")
        self.userid_lbl.setFont(QFont("Segoe UI", 10))
        self.userid_lbl.setStyleSheet("color: #888; border: none; background: transparent;")

        text_layout.addWidget(self.username_lbl)
        text_layout.addWidget(self.userid_lbl)

        profile_layout.addLayout(text_layout)
        profile_layout.addStretch()  # Push to left

        content_layout.addWidget(self.profile_card)

        # --- 3. Main Navigation ---
        all_cars_btn = self._create_nav_button("View All Vehicles", "")
        all_cars_btn.clicked.connect(lambda: QTimer.singleShot(150, self.vehicle_list_requested.emit))
        content_layout.addWidget(all_cars_btn)

        # --- 4. Categories Section ---
        content_layout.addSpacing(10)
        cat_header = QLabel("BROWSE CATEGORIES")
        cat_header.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        cat_header.setStyleSheet("color: #555; letter-spacing: 1px; margin-bottom: 5px;")
        content_layout.addWidget(cat_header)

        # Scroll Area for Categories
        self.cat_scroll = QScrollArea()
        self.cat_scroll.setWidgetResizable(True)
        self.cat_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.cat_scroll.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { width: 6px; background: #222; border-radius: 3px; }
            QScrollBar::handle:vertical { background: #444; border-radius: 3px; }
            QScrollBar:horizontal { height: 0px; }
        """)

        self.cat_container = QWidget()
        self.cat_container.setStyleSheet("background: transparent;")
        self.cat_layout = QVBoxLayout(self.cat_container)
        self.cat_layout.setContentsMargins(0, 0, 5, 0)
        self.cat_layout.setSpacing(5)  # Increased spacing slightly for better separation
        self.cat_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.cat_scroll.setWidget(self.cat_container)
        content_layout.addWidget(self.cat_scroll)

        if self.manager:
            self.populate_categories()

        content_layout.addStretch()

        # --- 5. Footer Actions ---
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("background-color: #333; margin: 5px 0;")
        content_layout.addWidget(line)

        history_btn = self._create_nav_button("My Rentals", "🕒")
        history_btn.clicked.connect(lambda: QTimer.singleShot(150, self.history_requested.emit))
        content_layout.addWidget(history_btn)

        support_btn = self._create_nav_button("Support / Chat", "💬")
        support_btn.clicked.connect(lambda: QTimer.singleShot(150, self.message_center_requested.emit))
        content_layout.addWidget(support_btn)

        logout_btn = self._create_nav_button("Sign Out", "🚪")
        logout_btn.setStyleSheet("""
            QPushButton {
                text-align: left; padding: 10px 15px; color: #ff6b6b;
                border: 1px solid transparent; background-color: transparent; border-radius: 6px; font-weight: bold;
            }
            QPushButton:hover { background-color: #2c0b0b; border: 1px solid #ff6b6b; }
        """)
        logout_btn.clicked.connect(self.logout_requested.emit)
        content_layout.addWidget(logout_btn)

        layout.addWidget(content_container)

    def _create_nav_button(self, text, icon):
        display_text = f"   {icon}   {text}" if icon else f"   {text}"
        btn = QPushButton(display_text)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setFont(QFont("Segoe UI", 10))
        btn.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding: 10px 15px;
                color: #ddd;
                border: 1px solid #333;
                background-color: transparent;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #333;
                color: white;
                border: 1px solid #555;
            }
        """)
        return btn

    def populate_categories(self):
        while self.cat_layout.count():
            item = self.cat_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

        try:
            categories = self.manager.get_categories()
            for cat in categories:
                btn = QPushButton(f"   {cat['name']}")  # Added padding spaces to match "View All" look
                btn.setCursor(Qt.CursorShape.PointingHandCursor)
                btn.setFont(QFont("Segoe UI", 10))

                # --- UPDATED STYLE: MATCHING "VIEW ALL VEHICLES" ---
                btn.setStyleSheet("""
                    QPushButton {
                        text-align: left;
                        padding: 10px 15px;
                        color: #ddd;
                        border: 1px solid #333;
                        background-color: transparent;
                        border-radius: 6px;
                    }
                    QPushButton:hover {
                        background-color: #333;
                        color: white;
                        border: 1px solid #555;
                    }
                """)
                btn.clicked.connect(
                    lambda checked, cid=cat['id']: QTimer.singleShot(150, lambda: self.category_selected.emit(cid)))
                self.cat_layout.addWidget(btn)
        except Exception as e:
            print(f"Error loading sidebar: {e}")

    def set_user_details(self, name, email, user_id):
        self.username_lbl.setText(name)
        self.userid_lbl.setText(f"Customer ID: {user_id}")

# --- 5. Admin Widgets ---
class SalesReportTab(BaseWidget):
    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.txns, self.chart = [], None

        # Initialize labels for the stat cards
        self.lbl_revenue = None
        self.lbl_bookings = None
        self.lbl_top_car = None
        self.lbl_aov = None

        self.setup_ui()
        self.connect_signals()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # --- 1. FILTER BAR ---
        filter_group = QGroupBox()
        filter_group.setStyleSheet("QGroupBox { border: none; background-color: #1e1e1e; border-radius: 8px; }")
        filter_layout = QHBoxLayout(filter_group)
        filter_layout.setContentsMargins(15, 10, 15, 10)

        # Time Filter
        filter_layout.addWidget(QLabel("Filter Period:"))
        self.period_combo = QComboBox()
        self.period_combo.addItems(["All Time", "Today", "Last 7 Days (Weekly)", "Last 30 Days (Monthly)"])
        self.period_combo.setFixedWidth(180)
        self.period_combo.setStyleSheet("""
            QComboBox { background-color: #252526; border: 1px solid #555; padding: 5px; color: white; }
            QComboBox:focus { border: 1px solid #0078d4; }
        """)
        filter_layout.addWidget(self.period_combo)

        # Chart View Toggle
        filter_layout.addSpacing(15)
        filter_layout.addWidget(QLabel("Chart View:"))
        self.chart_mode_combo = QComboBox()
        self.chart_mode_combo.addItems(["Most Rented (Count)", "Highest Earners (Revenue)"])
        self.chart_mode_combo.setFixedWidth(180)
        self.chart_mode_combo.setStyleSheet("""
            QComboBox { background-color: #252526; border: 1px solid #555; padding: 5px; color: white; }
            QComboBox:focus { border: 1px solid #0078d4; }
        """)
        filter_layout.addWidget(self.chart_mode_combo)

        # ID Search
        filter_layout.addSpacing(15)
        # --- FIX: Revert label to Transaction ID ---
        filter_layout.addWidget(QLabel("Search Trans ID:"))
        # -------------------------------------------
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("ID...")
        self.search_bar.setFixedWidth(100)
        self.search_bar.setValidator(QIntValidator(1, 9999999))
        self.search_bar.setStyleSheet(
            "QLineEdit { background-color: #252526; border: 1px solid #555; padding: 5px; color: white; }")
        filter_layout.addWidget(self.search_bar)

        self.search_btn = QPushButton("Go")
        self.search_btn.setFixedWidth(50)
        self.search_btn.setStyleSheet("background-color: #0078d4; color: white; border-radius: 4px;")
        filter_layout.addWidget(self.search_btn)

        # Export PDF Button
        filter_layout.addSpacing(10)
        self.export_btn = QPushButton("📄 Export PDF")
        self.export_btn.setFixedWidth(120)
        self.export_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.export_btn.setStyleSheet("background-color: #e74c3c; color: white; border-radius: 4px; font-weight: bold;")
        filter_layout.addWidget(self.export_btn)

        filter_layout.addStretch(1)
        layout.addWidget(filter_group)

        # --- 2. DASHBOARD STAT CARDS ---
        stats_container = QWidget()
        stats_layout = QHBoxLayout(stats_container)
        stats_layout.setContentsMargins(0, 0, 0, 0)
        stats_layout.setSpacing(15)

        # Helper to create cards
        def create_card(title, color):
            card = QFrame()
            card.setStyleSheet(f"""
                QFrame {{
                    background-color: #252526;
                    border-left: 5px solid {color};
                    border-radius: 6px;
                }}
            """)
            l = QVBoxLayout(card)
            l.setContentsMargins(15, 15, 15, 15)
            t_lbl = QLabel(title)
            t_lbl.setStyleSheet(
                "color: #aaa; font-size: 11px; font-weight: bold; border: none; text-transform: uppercase;")
            v_lbl = QLabel("...")
            v_lbl.setStyleSheet("color: white; font-size: 22px; font-weight: bold; border: none;")
            l.addWidget(t_lbl)
            l.addWidget(v_lbl)
            return card, v_lbl

        # Create the 4 cards
        card1, self.lbl_revenue = create_card("Total Revenue", "#27ae60")  # Green
        card2, self.lbl_bookings = create_card("Total Bookings", "#2980b9")  # Blue
        card3, self.lbl_top_car = create_card("Top Performing Car", "#e67e22")  # Orange
        card4, self.lbl_aov = create_card("Average Order Value", "#8e44ad")  # Purple

        stats_layout.addWidget(card1)
        stats_layout.addWidget(card2)
        stats_layout.addWidget(card3)
        stats_layout.addWidget(card4)

        layout.addWidget(stats_container)

        # --- 3. CHART AREA ---
        self.chart_lbl = QLabel("Chart will be displayed here.")
        self.chart_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.chart_lbl.setMinimumHeight(300)
        self.chart_lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.chart_lbl.setStyleSheet("border: 1px solid #333; background-color: #1e1e1e; border-radius: 8px;")
        layout.addWidget(self.chart_lbl)

        # --- 4. TABLE AREA (UPDATED WITH EXPAND BUTTON) ---
        header_layout = QHBoxLayout()
        title_lbl = self.create_label("Transaction Records", True, 14)
        header_layout.addWidget(title_lbl)

        header_layout.addStretch()  # Push button to right

        # New Expand Button
        self.expand_btn = QPushButton("⛶ Expand Table")
        self.expand_btn.setFixedSize(120, 45)
        self.expand_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.expand_btn.setStyleSheet("""
            QPushButton { background-color: #444; color: white; border: 1px solid #555; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #666; border-color: #888; }
        """)
        self.expand_btn.clicked.connect(self.open_expanded_view)
        header_layout.addWidget(self.expand_btn)

        layout.addLayout(header_layout)

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels(
            ["Date", "Trans ID", "User ID", "Client", "Car", "Add-ons", "Days", "Total"])
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.setAlternatingRowColors(True)
        self.table.setStyleSheet(
            "QTableWidget { background-color: #1e1e1e; alternate-background-color: #252526; border: 1px solid #333; gridline-color: #444; color: #ddd; outline: 0; } QHeaderView::section { background-color: #2d2d2d; padding: 4px; border: 1px solid #333; font-weight: bold; color: #eee; } QTableWidget::item { padding: 2px 5px; border: none; } QTableWidget::item:selected { background-color: transparent; color: #ddd; }")
        self.table.setWordWrap(True)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)

        self.table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setDefaultSectionSize(30)
        layout.addWidget(self.table)
        self.table.verticalHeader().setVisible(False)

    def connect_signals(self):
        self.search_btn.clicked.connect(self.handle_search)
        self.search_bar.returnPressed.connect(self.handle_search)
        self.period_combo.currentIndexChanged.connect(self.handle_period_filter)
        self.export_btn.clicked.connect(self.export_data_pdf)
        self.chart_mode_combo.currentIndexChanged.connect(lambda: self.populate_sales_report(self.txns))

    def handle_reset(self):
        self.period_combo.setCurrentIndex(0)
        self.search_bar.clear()
        self.populate_sales_report(self.manager.get_all_transactions())

    def handle_period_filter(self):
        idx = self.period_combo.currentIndex()
        now = datetime.datetime.now()
        if idx == 0:
            self.populate_sales_report(self.manager.get_all_transactions())
            return
        if idx == 1:
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            end = now.replace(hour=23, minute=59, second=59, microsecond=999999)
        elif idx == 2:
            start = (now - datetime.timedelta(days=7)).replace(hour=0, minute=0, second=0)
            end = now
        elif idx == 3:
            start = (now - datetime.timedelta(days=30)).replace(hour=0, minute=0, second=0)
            end = now
        txns = self.manager.get_transactions_by_range(start, end)
        self.populate_sales_report(txns)

    # --- FIX: Updated logic to search by Transaction ID ---
    def handle_search(self):
        txn_id_str = self.search_bar.text().strip()
        if not txn_id_str:
            self.handle_reset()  # Reset if search bar is cleared
            return

        try:
            # Call the new method to search by the transaction's ID
            txns = self.manager.get_transaction_by_id(int(txn_id_str))

            if txns:
                self.populate_sales_report(txns)
            else:
                QMessageBox.information(self, "Not Found", f"Transaction ID {txn_id_str} not found.")
                # Show all data after a failed search attempt
                self.handle_reset()
        except ValueError:
            QMessageBox.warning(self, "Invalid Input", "Please enter a valid numeric Transaction ID.")
        except Exception as e:
            QMessageBox.critical(self, "Search Error", f"An error occurred: {str(e)}")
            self.handle_reset()

    # -----------------------------------------------------

    def export_data_pdf(self):
        if not self.txns:
            QMessageBox.warning(self, "No Data", "No transactions available to export.")
            return

        filename, _ = QFileDialog.getSaveFileName(
            self, "Save PDF Report", f"Sales_Report_{datetime.datetime.now().strftime('%Y%m%d')}.pdf",
            "PDF Files (*.pdf)")

        if not filename: return

        try:
            doc = SimpleDocTemplate(filename, pagesize=landscape(letter), rightMargin=30, leftMargin=30, topMargin=30,
                                    bottomMargin=18)
            elements = []
            styles = getSampleStyleSheet()

            title = Paragraph(f"Ragadio Rentals - Sales Report", styles['Title'])
            elements.append(title)
            elements.append(Paragraph(
                f"Period: {self.period_combo.currentText()} | Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}",
                styles['Normal']))
            elements.append(Spacer(1, 20))

            table_data = [['Date', 'Trans ID', 'User ID', 'Client', 'Car Model', 'Add-ons', 'Days', 'Total']]
            total_revenue = 0.0

            for t in self.txns:
                services_str = ", ".join([s['name'] for s in t.services]) if t.services else "-"
                if len(services_str) > 25: services_str = services_str[:22] + "..."
                date_str = t.timestamp.strftime("%Y-%m-%d") if t.timestamp else "-"
                txn_val = float(t.final_total) if t.final_total is not None else 0.0
                row = [date_str, str(t.id), str(t.user.get('id', '-')), t.user.get('name', 'N/A'), t.car.name,
                       services_str, str(t.duration), format_peso(txn_val)]
                table_data.append(row)
                total_revenue += txn_val

            table_data.append(['GRAND TOTAL:', '', '', '', '', '', '', format_peso(total_revenue)])
            col_widths = [70, 50, 50, 110, 140, 180, 40, 90]
            table = Table(table_data, colWidths=col_widths)
            style = TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('ALIGN', (3, 1), (5, -1), 'LEFT'),
                ('ALIGN', (-1, 1), (-1, -1), 'RIGHT'),
                ('BACKGROUND', (0, -1), (-1, -1), colors.grey),
                ('TEXTCOLOR', (0, -1), (-1, -1), colors.whitesmoke),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('SPAN', (0, -1), (6, -1)),
                ('ALIGN', (0, -1), (6, -1), 'RIGHT'),
            ])
            table.setStyle(style)
            elements.append(table)
            doc.build(elements)
            QMessageBox.information(self, "Success", f"PDF Report saved successfully:\n{filename}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to generate PDF:\n{str(e)}")

    def generate_chart(self):
        try:
            data_list = []
            for t in self.txns:
                val = float(t.final_total) if t.final_total is not None else 0.0
                data_list.append({'car_model': t.car.name, 'total': val})

            df = pd.DataFrame(data_list)
            if df.empty: return None

            mode = self.chart_mode_combo.currentText()
            if "Revenue" in mode:
                plot_data = df.groupby('car_model')['total'].sum().sort_values(ascending=False)
                title_suffix = "(Total Revenue)"
            else:
                plot_data = df['car_model'].value_counts()
                title_suffix = "(Rental Count)"

            colors = plt.cm.viridis(range(len(plot_data)))

            plt.figure(figsize=(12, 6), facecolor='#1e1e1e')
            ax = plt.gca()
            ax.set_facecolor('#1e1e1e')

            plot_data.plot(kind='bar', color=colors, width=0.6)

            text_color = '#ecf0f1'
            plt.title(f'Top Vehicles {title_suffix}', fontsize=14, color=text_color, pad=20)
            plt.xticks(rotation=45, ha='right', fontsize=9, color=text_color)
            plt.xlabel('', fontsize=10)
            plt.yticks(fontsize=9, color=text_color)
            if "Revenue" in mode:
                def currency_fmt(x, pos):
                    if x >= 1_000_000: return f'P{x * 1e-6:.1f}M'
                    if x >= 1_000: return f'P{x * 1e-3:.0f}k'
                    return f'P{x:.0f}'

                ax.yaxis.set_major_formatter(ticker.FuncFormatter(currency_fmt))
            else:
                ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))

            plt.grid(axis='y', linestyle='--', alpha=0.3, color='white')
            ax.spines['bottom'].set_color(text_color)
            ax.spines['left'].set_color(text_color)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            plt.tight_layout()

            filename = 'sales_chart.png'
            plt.savefig(filename, facecolor=ax.get_facecolor())
            plt.close()
            return filename
        except Exception as e:
            print(f"Chart Error: {e}")
            return None

    def populate_sales_report(self, txns):
        self.txns = txns

        # --- 1. CALCULATE STATS ---
        total_revenue = sum(float(tx.final_total) for tx in txns if tx.final_total is not None)
        total_bookings = len(txns)

        # Calculate Top Performing Car (Most frequent)
        top_car = "N/A"
        if total_bookings > 0:
            df = pd.DataFrame([t.car.name for t in txns], columns=['car'])
            if not df.empty:
                top_car = df['car'].mode()[0]

        # Calculate Average Order Value
        avg_order = (total_revenue / total_bookings) if total_bookings > 0 else 0.0

        # --- 2. UPDATE STAT CARDS ---
        self.lbl_revenue.setText(format_peso(total_revenue))
        self.lbl_bookings.setText(str(total_bookings))
        self.lbl_top_car.setText(str(top_car))
        self.lbl_aov.setText(format_peso(avg_order))

        # --- 3. REFRESH CHART & TABLE ---
        chart_file = self.generate_chart()
        self.chart = QPixmap(chart_file) if chart_file else None
        self.refresh_scaled_chart()

        self.table.setRowCount(len(txns))
        for row, tx in enumerate(txns):
            date = tx.timestamp.strftime("%Y-%m-%d") if tx.timestamp else "-"
            # Safely handle service strings
            if tx.services:
                # Assuming services is a list of dicts: [{'name':'Driver', 'cost':500}, ...]
                if isinstance(tx.services, list) and len(tx.services) > 0 and isinstance(tx.services[0], dict):
                    # FIX: Correctly extract and join all service names
                    svcs = ", ".join([s.get('name', '-') for s in tx.services])
                else:
                    svcs = "-"
            else:
                svcs = "-"

            self.table.setItem(row, 0, QTableWidgetItem(date))
            self.table.setItem(row, 1, QTableWidgetItem(str(tx.id)))
            self.table.setItem(row, 2, QTableWidgetItem(str(tx.user.get('id', '-'))))
            self.table.setItem(row, 3, QTableWidgetItem(tx.user.get('name', '-')))
            self.table.setItem(row, 4, QTableWidgetItem(tx.car.name))
            self.table.setItem(row, 5, QTableWidgetItem(svcs))
            days_item = QTableWidgetItem(str(tx.duration))
            days_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 6, days_item)
            total_item = QTableWidgetItem(format_peso(tx.final_total))
            total_item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            self.table.setItem(row, 7, total_item)
        self.table.resizeRowsToContents()

    def refresh_scaled_chart(self):
        if self.chart and not self.chart.isNull():
            scaled = self.chart.scaled(self.chart_lbl.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            self.chart_lbl.setPixmap(scaled)
        else:
            self.chart_lbl.setText("No data available for chart.")

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.refresh_scaled_chart()

    def open_expanded_view(self):
        """Opens a large dialog with the full transaction table."""
        if not self.txns:
            QMessageBox.information(self, "Info", "No data to view.")
            return

        # Create a large popup dialog
        dialog = QDialog(self)
        dialog.setWindowTitle("Transaction Records - Expanded View")
        dialog.resize(1300, 800)
        dialog.setStyleSheet("background-color: #1e1e1e; color: #ddd;")

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel("Full Transaction History")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #0078d4; margin-bottom: 10px;")
        layout.addWidget(title)

        # Create a new table for the dialog
        big_table = QTableWidget()
        big_table.setColumnCount(8)
        big_table.setHorizontalHeaderLabels(
            ["Date", "Trans ID", "User ID", "Client", "Car", "Add-ons", "Days", "Total"])
        big_table.verticalHeader().setVisible(False)
        big_table.setAlternatingRowColors(True)
        big_table.setStyleSheet(self.table.styleSheet())

        # --- THE FIX: Make columns fill the screen width ---
        header = big_table.horizontalHeader()

        # 1. Keep small columns tight (Date, IDs, Days, Total)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)  # Date
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)  # Trans ID
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)  # User ID
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)  # Days
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)  # Total

        # 2. Stretch the big text columns to fill all remaining space (Client, Car, Add-ons)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        # --------------------------------------------------

        # Populate the big table with data
        big_table.setRowCount(len(self.txns))
        for row, tx in enumerate(self.txns):
            date = tx.timestamp.strftime("%Y-%m-%d") if tx.timestamp else "-"

            # Handle add-ons display
            if tx.services:
                if isinstance(tx.services, list) and len(tx.services) > 0 and isinstance(tx.services[0], dict):
                    # Join all services if multiple, or just take the first
                    svcs = ", ".join([s.get('name', '-') for s in tx.services])
                else:
                    svcs = "-"
            else:
                svcs = "-"

            big_table.setItem(row, 0, QTableWidgetItem(date))
            big_table.setItem(row, 1, QTableWidgetItem(str(tx.id)))
            big_table.setItem(row, 2, QTableWidgetItem(str(tx.user.get('id', '-'))))
            big_table.setItem(row, 3, QTableWidgetItem(tx.user.get('name', '-')))
            big_table.setItem(row, 4, QTableWidgetItem(tx.car.name))
            big_table.setItem(row, 5, QTableWidgetItem(svcs))

            days_item = QTableWidgetItem(str(tx.duration))
            days_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            big_table.setItem(row, 6, days_item)

            total_item = QTableWidgetItem(format_peso(tx.final_total))
            total_item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            big_table.setItem(row, 7, total_item)

        layout.addWidget(big_table)

        # Close Button
        close_btn = QPushButton("Close")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setFixedSize(120, 40)
        close_btn.setStyleSheet("background-color: #c0392b; color: white; font-weight: bold; border-radius: 5px;")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)

        dialog.exec()

class CarEditDialog(QDialog):
    def __init__(self, car_data, categories, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Car Details")
        self.setMinimumWidth(400)
        self.selected_image_path = None

        self.layout = QFormLayout(self)

        img_row = QHBoxLayout()
        self.img_preview_lbl = QLabel()
        self.img_preview_lbl.setFixedSize(100, 70)
        self.img_preview_lbl.setStyleSheet("background-color: #333; border: 1px solid #555;")
        current_img = car_data.get('image_path')
        self.img_preview_lbl.setPixmap(load_car_pixmap(current_img, 100, 70))

        self.select_img_btn = QPushButton("Change Image")
        self.select_img_btn.clicked.connect(self.select_image)

        img_row.addWidget(self.img_preview_lbl)
        img_row.addWidget(self.select_img_btn)
        self.layout.addRow("Vehicle Image:", img_row)

        self.name_in = QLineEdit(car_data['name'])
        self.price_in = QLineEdit(str(car_data['price_per_day']))
        self.price_in.setValidator(QDoubleValidator(0.00, 99999.99, 2))

        qty = car_data.get('quantity')
        if qty is None: qty = 0
        self.qty_in = QLineEdit(str(qty))
        self.qty_in.setValidator(QIntValidator(0, 999))

        self.category_combo = QComboBox()

        current_index = 0
        for i, cat in enumerate(categories):
            self.category_combo.addItem(cat['name'], cat['id'])
            if str(cat['id']) == str(car_data['category_id']):
                current_index = i
        self.category_combo.setCurrentIndex(current_index)

        self.layout.addRow("Name:", self.name_in)
        self.layout.addRow("Price (₱):", self.price_in)
        self.layout.addRow("Quantity:", self.qty_in)
        self.layout.addRow("Category:", self.category_combo)

        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)

        self.layout.addWidget(self.buttons)

    def select_image(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Select Car Image", "", "Image Files (*.png *.jpg *.jpeg)")
        if fname:
            self.selected_image_path = fname
            pixmap = QPixmap(fname)
            self.img_preview_lbl.setPixmap(
                pixmap.scaled(100, 70, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def get_data(self):
        if not self.name_in.text().strip() or not self.price_in.text().strip():
            return None
        try:
            qty_val = int(self.qty_in.text().strip())
        except ValueError:
            qty_val = 0

        return {
            "name": self.name_in.text().strip(),
            "price": float(self.price_in.text()),
            "category_id": self.category_combo.currentData(),
            "quantity": qty_val,
            "image_path": self.selected_image_path
        }


class InventoryTab(BaseWidget):
    availability_updated = pyqtSignal()
    services_updated = pyqtSignal()

    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.car_data = []
        self.all_categories = []
        self.all_services_data = []
        self.setup_ui()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(30, 30, 30, 30)

        nav_container = QWidget()
        nav_container.setStyleSheet(".QWidget { background-color: #252526; border-radius: 8px; }")
        nav_layout = QHBoxLayout(nav_container)
        nav_layout.setContentsMargins(10, 10, 10, 10)

        self.car_mgmt_btn = QPushButton("Manage Vehicles")
        self.car_mgmt_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.car_mgmt_btn.setCheckable(True)
        self.car_mgmt_btn.setChecked(True)
        self.car_mgmt_btn.clicked.connect(self._show_car_ui)

        self.service_mgmt_btn = QPushButton("Manage Add-ons")
        self.service_mgmt_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.service_mgmt_btn.setCheckable(True)
        self.service_mgmt_btn.clicked.connect(self._show_service_ui)

        btn_style = """
            QPushButton { background-color: transparent; color: #888; font-size: 14px; font-weight: bold; border: none; padding: 10px; }
            QPushButton:checked { background-color: #0078d4; color: white; border-radius: 5px; }
            QPushButton:hover { color: white; }
        """
        self.car_mgmt_btn.setStyleSheet(btn_style)
        self.service_mgmt_btn.setStyleSheet(btn_style)

        nav_layout.addWidget(self.car_mgmt_btn)
        nav_layout.addWidget(self.service_mgmt_btn)
        main_layout.addWidget(nav_container)

        self.inventory_stack = QStackedWidget()
        main_layout.addWidget(self.inventory_stack)

        self.car_widget = QWidget()
        self.service_widget = QWidget()

        self.inventory_stack.addWidget(self.car_widget)
        self.inventory_stack.addWidget(self.service_widget)

        self.setup_car_inventory_ui()
        self.setup_service_inventory_ui()

        self.populate_categories_dropdown()

    def _show_car_ui(self):
        self.inventory_stack.setCurrentWidget(self.car_widget)
        self.car_mgmt_btn.setChecked(True)
        self.service_mgmt_btn.setChecked(False)

    def _show_service_ui(self):
        self.inventory_stack.setCurrentWidget(self.service_widget)
        self.car_mgmt_btn.setChecked(False)
        self.service_mgmt_btn.setChecked(True)

    def setup_car_inventory_ui(self):
        layout = QVBoxLayout(self.car_widget)
        layout.setSpacing(10)
        layout.setContentsMargins(0, 0, 0, 0)

        # --- 1. Add New Vehicle Section ---
        self.add_group = QGroupBox("  Add New Vehicle  ")
        self.add_group.setStyleSheet("""
            QGroupBox { background-color: #1e1e1e; border: 1px solid #333; border-radius: 8px; margin-top: 10px; font-weight: bold; color: #ccc; }
            QGroupBox::title { subcontrol-origin: margin; left: 15px; padding: 0 5px; color: #0078d4; }
        """)

        form_layout = QFormLayout(self.add_group)
        form_layout.setContentsMargins(5, 5, 5, 5)
        form_layout.setSpacing(4)
        form_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        input_style = """
            QLineEdit { 
                background-color: #252526; border: 1px solid #555; border-radius: 4px; padding: 5px; color: white; 
            } 
            QLineEdit:focus { border: 1px solid #0078d4; } 
            QComboBox { 
                background-color: #252526; border: 1px solid #555; border-radius: 4px; padding: 5px; color: white; 
            } 
            QComboBox::drop-down { 
                border: none; background: #252526; 
            } 
            QComboBox QAbstractItemView { 
                background-color: #252526; 
                border: 1px solid #555; 
                selection-background-color: #0078d4; 
                color: white; 
                outline: none;
            }
        """

        self.add_car_category_combo = QComboBox()
        self.add_car_category_combo.setFixedWidth(300)
        self.add_car_category_combo.setStyleSheet(input_style)

        self.add_car_name_in = QLineEdit()
        self.add_car_name_in.setPlaceholderText("e.g. Toyota Fortuner")
        self.add_car_name_in.setFixedWidth(300)
        self.add_car_name_in.setStyleSheet(input_style)

        self.add_car_price_in = QLineEdit()
        self.add_car_price_in.setPlaceholderText("0.00")
        self.add_car_price_in.setValidator(QDoubleValidator(0.00, 99999.99, 2))
        self.add_car_price_in.setFixedWidth(300)
        self.add_car_price_in.setStyleSheet(input_style)

        self.add_car_qty_in = QLineEdit()
        self.add_car_qty_in.setPlaceholderText("Qty (e.g. 1)")
        self.add_car_qty_in.setValidator(QIntValidator(1, 999))
        self.add_car_qty_in.setFixedWidth(300)
        self.add_car_qty_in.setStyleSheet(input_style)

        # --- Image Layout (MODIFIED) ---
        self.add_car_image_path = None

        # Make the label itself clickable
        self.add_car_img_preview = QLabel("Click to\nSelect Image")
        self.add_car_img_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.add_car_img_preview.setFixedSize(100, 70)
        self.add_car_img_preview.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_car_img_preview.setStyleSheet("""
            QLabel { background-color: #333; border: 1px solid #555; color: #888; font-size: 10px; border-radius: 4px; }
            QLabel:hover { border: 1px solid #0078d4; background-color: #3a3a3a; }
        """)
        # Connect click event
        self.add_car_img_preview.mousePressEvent = lambda event: self.handle_select_add_car_image()

        form_layout.addRow("Category:", self.add_car_category_combo)
        form_layout.addRow("Model Name:", self.add_car_name_in)
        form_layout.addRow("Daily Rate (₱):", self.add_car_price_in)
        form_layout.addRow("Quantity:", self.add_car_qty_in)
        form_layout.addRow("Image:", self.add_car_img_preview)

        self.add_car_btn = QPushButton("Add Vehicle to Fleet")
        self.add_car_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_car_btn.setFixedWidth(180)
        self.add_car_btn.setStyleSheet(
            "background-color: #28a745; color: white; border-radius: 4px; padding: 8px; font-weight: bold;")
        self.add_car_btn.clicked.connect(self.handle_add_car)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(self.add_car_btn)
        form_layout.addRow(btn_row)

        layout.addWidget(self.add_group, 0)

        # --- 2. Fleet Inventory Section ---
        table_group = QGroupBox("  Fleet Inventory  ")
        table_group.setStyleSheet("""
            QGroupBox { background-color: #1e1e1e; border: 1px solid #333; border-radius: 8px; margin-top: 15px; color: #ccc; font-weight: bold; }
            QGroupBox::title { subcontrol-origin: margin; left: 15px; padding: 0 5px; color: #0078d4; }
        """)
        table_layout = QVBoxLayout(table_group)
        table_layout.setContentsMargins(15, 25, 15, 15)

        filter_layout = QHBoxLayout()
        self.inv_search_in = QLineEdit()
        self.inv_search_in.setPlaceholderText("🔍 Search Vehicle...")
        self.inv_search_in.setFixedWidth(250)
        self.inv_search_in.setStyleSheet(input_style)
        self.inv_search_in.textChanged.connect(self.filter_inventory_table)

        self.inv_filter_combo = QComboBox()
        self.inv_filter_combo.addItem("All Categories")
        self.inv_filter_combo.setFixedWidth(250)
        self.inv_filter_combo.setStyleSheet(input_style)
        self.inv_filter_combo.currentIndexChanged.connect(self.filter_inventory_table)

        filter_layout.addWidget(QLabel("Search:"))
        filter_layout.addWidget(self.inv_search_in)
        filter_layout.addSpacing(20)
        filter_layout.addWidget(QLabel("Category:"))
        filter_layout.addWidget(self.inv_filter_combo)

        filter_layout.addStretch()
        self.expand_btn = QPushButton("⛶ Expand")
        self.expand_btn.setFixedSize(90, 30)
        self.expand_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.expand_btn.setStyleSheet(
            "QPushButton { background-color: #555; color: white; border-radius: 4px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #777; }")
        self.expand_btn.clicked.connect(self.toggle_expand)
        filter_layout.addWidget(self.expand_btn)

        table_layout.addLayout(filter_layout)

        actions_layout = QHBoxLayout()
        self.status_combo = QComboBox()
        self.status_combo.addItem("Mark as: Available", 1)
        self.status_combo.addItem("Mark as: Unavailable", 0)
        self.status_combo.setFixedWidth(180)
        self.status_combo.setStyleSheet(input_style)

        self.apply_bulk_btn = QPushButton("Apply Status")
        self.apply_bulk_btn.setFixedWidth(120)
        self.apply_bulk_btn.clicked.connect(self.apply_bulk_availability)
        self.apply_bulk_btn.setStyleSheet("background-color: #0078d4; color: white; border-radius: 4px; padding: 6px;")
        actions_layout.addWidget(QLabel("Bulk Actions:"))
        actions_layout.addWidget(self.status_combo)
        actions_layout.addWidget(self.apply_bulk_btn)
        actions_layout.addStretch()
        table_layout.addLayout(actions_layout)

        self.availability_table = QTableWidget()
        self.availability_table.verticalHeader().setVisible(False)
        self.availability_table.setColumnCount(7)
        self.availability_table.setHorizontalHeaderLabels(
            ["Car Model", "Category", "Price", "Qty", "Status", "Select", "Actions"])
        self.availability_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        header = self.availability_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.availability_table.setColumnWidth(1, 240)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        self.availability_table.setColumnWidth(2, 100)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.availability_table.setColumnWidth(3, 50)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
        self.availability_table.setColumnWidth(4, 100)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Fixed)
        self.availability_table.setColumnWidth(5, 50)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.Fixed)
        self.availability_table.setColumnWidth(6, 100)
        v_header = self.availability_table.verticalHeader()
        v_header.setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        v_header.setDefaultSectionSize(50)
        self.availability_table.setStyleSheet("QTableWidget { border: 1px solid #444; gridline-color: #444; }")

        table_layout.addWidget(self.availability_table, 1)
        layout.addWidget(table_group, 10)

        self.populate_categories_dropdown()

    def toggle_expand(self):
        if self.add_group.isVisible():
            self.add_group.hide()
            self.expand_btn.setText("⛶ Restore")
            self.expand_btn.setStyleSheet(
                "QPushButton { background-color: #e67e22; color: white; border-radius: 4px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #d35400; }")
        else:
            self.add_group.show()
            self.expand_btn.setText("⛶ Expand")
            self.expand_btn.setStyleSheet(
                "QPushButton { background-color: #555; color: white; border-radius: 4px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #777; }")

    def setup_service_inventory_ui(self):
        layout = QVBoxLayout(self.service_widget)
        layout.setSpacing(10)
        layout.setContentsMargins(0, 0, 0, 0)

        add_group = QGroupBox("  Add New Add-on  ")
        add_group.setStyleSheet("""
            QGroupBox { 
                background-color: #1e1e1e; 
                border: 1px solid #333; 
                border-radius: 8px; 
                margin: 0px; 
                font-weight: bold; 
                color: #ccc; 
            }
            QGroupBox::title { 
                subcontrol-origin: margin; 
                left: 15px; 
                padding: 0 5px; 
                color: #0078d4; 
            }
        """)
        form_layout = QFormLayout(add_group)
        form_layout.setContentsMargins(5, 5, 5, 5)
        form_layout.setSpacing(4)
        form_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        input_style = "QLineEdit { background-color: #252526; border: 1px solid #555; border-radius: 4px; padding: 5px; color: white; } QLineEdit:focus { border: 1px solid #0078d4; }"

        self.add_service_name_in = QLineEdit()
        self.add_service_name_in.setFixedWidth(300)
        self.add_service_name_in.setStyleSheet(input_style)
        self.add_service_price_in = QLineEdit()
        self.add_service_price_in.setValidator(QDoubleValidator(0.00, 99999.99, 2))
        self.add_service_price_in.setFixedWidth(300)
        self.add_service_price_in.setStyleSheet(input_style)
        self.add_service_is_daily_btn = QPushButton("Charge Per Day?  ⬜")
        self.add_service_is_daily_btn.setCheckable(True)
        self.add_service_is_daily_btn.setFixedWidth(300)
        self.add_service_is_daily_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_service_is_daily_btn.toggled.connect(lambda checked: self.add_service_is_daily_btn.setText(
            "Charge Per Day?  ✅" if checked else "Charge Per Day?  ⬜"))
        self.add_service_is_daily_btn.setStyleSheet(
            "QPushButton { background-color: #252526; border: 1px solid #555; border-radius: 4px; padding: 5px; color: #aaa; text-align: left; } QPushButton:checked { border: 1px solid #0078d4; color: white; } QPushButton:hover { border: 1px solid #777; }")

        form_layout.addRow("Service Name:", self.add_service_name_in)
        form_layout.addRow("Price (₱):", self.add_service_price_in)
        form_layout.addRow("", self.add_service_is_daily_btn)

        self.add_service_btn = QPushButton("Add Service")
        self.add_service_btn.setFixedWidth(150)
        self.add_service_btn.clicked.connect(self.handle_add_service)
        self.add_service_btn.setStyleSheet(
            "background-color: #28a745; color: white; border-radius: 4px; padding: 8px; font-weight: bold;")

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(self.add_service_btn)
        form_layout.addRow(btn_row)

        layout.addWidget(add_group, 0)

        table_group = QGroupBox("  Active Services  ")
        table_group.setStyleSheet("""
            QGroupBox { background-color: #1e1e1e; border: 1px solid #333; border-radius: 8px; margin-top: 15px; color: #ccc; font-weight: bold; }
            QGroupBox::title { subcontrol-origin: margin; left: 15px; padding: 0 5px; color: #0078d4; }
        """)
        table_layout = QVBoxLayout(table_group)
        refresh_btn = QPushButton("Refresh List")
        refresh_btn.setFixedWidth(120)
        refresh_btn.clicked.connect(self.populate_services_table)
        refresh_btn.setStyleSheet("background-color: #555; color: white; border-radius: 4px; padding: 6px;")
        top_bar = QHBoxLayout()
        top_bar.addStretch()
        top_bar.addWidget(refresh_btn)
        table_layout.addLayout(top_bar)

        self.service_table = QTableWidget()
        self.service_table.verticalHeader().setVisible(False)
        self.service_table.setColumnCount(5)
        self.service_table.setHorizontalHeaderLabels(["ID", "Name", "Price", "Type", "Actions"])
        self.service_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.service_table.setStyleSheet("QTableWidget { border: 1px solid #444; gridline-color: #444; }")
        table_layout.addWidget(self.service_table)

        layout.addWidget(table_group, 10)

    def populate_categories_dropdown(self):
        self.add_car_category_combo.clear()
        current_filter = self.inv_filter_combo.currentText()
        self.inv_filter_combo.blockSignals(True)
        self.inv_filter_combo.clear()
        self.inv_filter_combo.addItem("All Categories")
        try:
            cats = self.manager.get_categories()
            self.all_categories = cats
            if not cats:
                self.add_car_category_combo.addItem("Error: No categories", "")
            else:
                for cat in cats:
                    self.add_car_category_combo.addItem(cat['name'], cat['id'])
                    self.inv_filter_combo.addItem(cat['name'])
        except:
            self.add_car_category_combo.addItem("Error", "")
        idx = self.inv_filter_combo.findText(current_filter)
        if idx != -1: self.inv_filter_combo.setCurrentIndex(idx)
        self.inv_filter_combo.blockSignals(False)
        self.filter_inventory_table()

    def handle_select_add_car_image(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Select Car Image", "", "Image Files (*.png *.jpg *.jpeg)")
        if fname:
            self.add_car_image_path = fname
            pixmap = QPixmap(fname)
            # The pixmap will automatically replace the text
            self.add_car_img_preview.setPixmap(
                pixmap.scaled(100, 70, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def handle_add_car(self):
        cat = self.add_car_category_combo.currentData()
        name = self.add_car_name_in.text().strip()
        price = self.add_car_price_in.text().strip()
        qty_str = self.add_car_qty_in.text().strip()
        img_path = self.add_car_image_path
        if not all([cat, name, price, qty_str]):
            return QMessageBox.warning(self, "Missing", "Fill all fields.")
        try:
            self.manager.add_new_car(cat, name, float(price), int(qty_str), img_path)
            self.add_car_name_in.clear()
            self.add_car_price_in.clear()
            self.add_car_qty_in.clear()
            self.add_car_image_path = None
            # Reset the image preview label
            self.add_car_img_preview.clear()
            self.add_car_img_preview.setText("Click to\nSelect Image")
            self.populate_availability_table()
            self.availability_updated.emit()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def populate_availability_table(self):
        self.car_data = self.manager.get_all_cars_for_admin()
        self.availability_table.setRowCount(len(self.car_data))
        for row, car in enumerate(self.car_data):
            self.availability_table.setItem(row, 0, QTableWidgetItem(car['name']))
            self.availability_table.setItem(row, 1, QTableWidgetItem(car['category_name']))
            self.availability_table.setItem(row, 2, QTableWidgetItem(format_peso(car['price_per_day'])))
            raw_qty = car.get('quantity')
            qty_val = raw_qty if raw_qty is not None else 0
            self.availability_table.setItem(row, 3, QTableWidgetItem(str(qty_val)))
            status_text = "✅ Available" if car['is_available'] else "❌ Unavailable"
            if qty_val <= 0: status_text = "❌ Sold Out"
            self.availability_table.setItem(row, 4, QTableWidgetItem(status_text))
            cb_widget = QWidget()
            cb_layout = QHBoxLayout(cb_widget)
            cb_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            cb_layout.setContentsMargins(0, 0, 0, 0)
            check_btn = QPushButton()
            check_btn.setCheckable(True)
            check_btn.setFixedSize(20, 20)
            check_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            check_btn.setProperty("car_id", car['id'])
            check_btn.setStyleSheet(
                "QPushButton { background-color: #222; border: 2px solid #666; border-radius: 4px; color: white; font-weight: bold; font-size: 14px; padding-bottom: 3px; } QPushButton:checked { background-color: #0078d4; border-color: #0078d4; } QPushButton:hover { border-color: #888; }")
            check_btn.toggled.connect(lambda checked, btn=check_btn: btn.setText("✔" if checked else ""))
            cb_layout.addWidget(check_btn)
            self.availability_table.setCellWidget(row, 5, cb_widget)
            act_widget = QWidget()
            act_layout = QHBoxLayout(act_widget)
            act_layout.setContentsMargins(2, 2, 2, 2)
            edit_btn = QPushButton("Edit")
            edit_btn.clicked.connect(lambda _, r=row: self.handle_edit_car(r))
            del_btn = QPushButton("Del")
            del_btn.setStyleSheet("background-color: #c0392b; color: white;")
            del_btn.clicked.connect(lambda _, r=row: self.handle_delete_car(r))
            act_layout.addWidget(edit_btn)
            act_layout.addWidget(del_btn)
            self.availability_table.setCellWidget(row, 6, act_widget)
        self.filter_inventory_table()

    def filter_inventory_table(self):
        search_text = self.inv_search_in.text().lower()
        target_cat = self.inv_filter_combo.currentText()
        for row in range(self.availability_table.rowCount()):
            name_item = self.availability_table.item(row, 0)
            cat_item = self.availability_table.item(row, 1)
            if not name_item or not cat_item: continue
            name = name_item.text().lower()
            cat = cat_item.text()
            name_match = search_text in name
            cat_match = (target_cat == "All Categories") or (cat == target_cat)
            self.availability_table.setRowHidden(row, not (name_match and cat_match))

    def handle_edit_car(self, row):
        car = self.car_data[row]
        dialog = CarEditDialog(car, self.all_categories, self)
        if dialog.exec() and (data := dialog.get_data()):
            try:
                self.manager.edit_car(car['id'], data['name'], data['price'], data['category_id'], data['quantity'],
                                      data['image_path'])
            except Exception as e:
                QMessageBox.critical(self, "Update Error", f"Failed to save: {str(e)}")
            finally:
                self.populate_availability_table()
                self.availability_updated.emit()

    def handle_delete_car(self, row):
        car = self.car_data[row]
        if QMessageBox.question(self, "Delete", f"Delete '{car['name']}'?",
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.manager.delete_car(car['id'])
            self.populate_availability_table()
            self.availability_updated.emit()

    def apply_bulk_availability(self):
        status = self.status_combo.currentData()
        count = 0
        for row in range(self.availability_table.rowCount()):
            if (w := self.availability_table.cellWidget(row, 5)) and (
                    btn := w.findChild(QPushButton)) and btn.isChecked():
                self.manager.update_car_unit_availability(btn.property("car_id"), status)
                count += 1
        if count:
            self.populate_availability_table()
            self.availability_updated.emit()
            QMessageBox.information(self, "Done", f"Updated {count} cars.")
        else:
            QMessageBox.warning(self, "Error", "No cars selected.")

    def handle_add_service(self):
        name = self.add_service_name_in.text().strip()
        price = self.add_service_price_in.text().strip()
        if name and price:
            is_daily = self.add_service_is_daily_btn.isChecked()
            self.manager.add_new_service(name, float(price), is_daily)
            self.add_service_name_in.clear()
            self.add_service_price_in.clear()
            self.add_service_is_daily_btn.setChecked(False)
            self.populate_services_table()
            self.services_updated.emit()

    def populate_services_table(self):
        data = self.manager.get_all_services_with_ids()
        self.all_services_data = data
        self.service_table.setRowCount(len(data))
        for r, s in enumerate(data):
            self.service_table.setItem(r, 0, QTableWidgetItem(str(s['id'])))
            self.service_table.setItem(r, 1, QTableWidgetItem(s['name']))
            self.service_table.setItem(r, 2, QTableWidgetItem(format_peso(s['price'])))
            self.service_table.setItem(r, 3, QTableWidgetItem("Per Day" if s['is_daily'] else "One-Time"))
            del_btn = QPushButton("Delete")
            del_btn.setStyleSheet("background-color: #c0392b; color: white;")
            del_btn.clicked.connect(lambda _, row=r: self.handle_delete_service(row))
            self.service_table.setCellWidget(r, 4, del_btn)

    def handle_delete_service(self, row):
        svc = self.all_services_data[row]
        if QMessageBox.question(self, "Delete", f"Delete '{svc['name']}'?",
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.manager.delete_service(svc['id'])
            self.populate_services_table()
            self.services_updated.emit()

class ReplyDialog(QDialog):
    def __init__(self, message_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Reply to Customer")
        self.setFixedSize(500, 550)
        self.message_data = message_data
        self.reply_text = ""
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        info_group = QGroupBox("Customer Message")
        info_group.setStyleSheet("""
            QGroupBox { border: 1px solid #444; border-radius: 6px; margin-top: 10px; font-weight: bold; color: #ccc; }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; color: #0078d4; }
            QLabel { color: #ddd; }
        """)
        info_layout = QFormLayout(info_group)
        info_layout.addRow("From:", QLabel(self.message_data['user_name']))
        info_layout.addRow("Email:", QLabel(self.message_data['user_email']))

        msg_view = QTextEdit()
        msg_view.setPlainText(self.message_data['message_text'])
        msg_view.setReadOnly(True)
        msg_view.setMinimumHeight(150)
        msg_view.setStyleSheet("background-color: #222; border: none; color: #aaa;")
        info_layout.addRow("Message:", msg_view)

        layout.addWidget(info_group)

        layout.addWidget(QLabel("Your Response:"))
        self.reply_input = QTextEdit()
        self.reply_input.setPlaceholderText("Type your reply here...")
        if self.message_data.get('admin_reply'):
            self.reply_input.setPlainText(self.message_data['admin_reply'])

        self.reply_input.setStyleSheet("""
            QTextEdit { background-color: #252526; border: 1px solid #555; border-radius: 4px; color: white; padding: 5px; }
            QTextEdit:focus { border: 1px solid #0078d4; }
        """)
        layout.addWidget(self.reply_input)

        btn_layout = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        cancel_btn.setStyleSheet(
            "background-color: transparent; border: 1px solid #555; color: #ccc; border-radius: 4px; padding: 8px;")
        send_btn = QPushButton("Send Reply")
        send_btn.clicked.connect(self.handle_send)
        send_btn.setStyleSheet(
            "background-color: #28a745; color: white; border-radius: 4px; padding: 8px; font-weight: bold;")
        btn_layout.addStretch()
        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(send_btn)
        layout.addLayout(btn_layout)

    def handle_send(self):
        text = self.reply_input.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "Empty", "Please type a message.")
            return
        self.reply_text = text
        self.accept()


class MessageWidget(BaseWidget):
    message_sent = pyqtSignal()
    back_to_main = pyqtSignal()

    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.current_name = ""
        self.current_email = ""
        self.setup_ui()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # --- 1. Header ---
        header_container = QWidget()
        header_container.setFixedHeight(70)
        header_container.setStyleSheet("background-color: #252526; border-bottom: 1px solid #333;")
        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        title_lbl = QLabel("🎫  Customer Service")
        title_lbl.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title_lbl.setStyleSheet("color: white; border: none;")

        subtitle_lbl = QLabel(" •  Chat with us or submit a ticket for issues.")
        subtitle_lbl.setStyleSheet("color: #888; font-size: 14px; border: none;")

        back_btn = QPushButton("← Back")
        back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        back_btn.setFixedSize(80, 30)
        back_btn.setStyleSheet("""
            QPushButton { background-color: transparent; color: #ccc; border: 1px solid #555; border-radius: 15px; font-weight: bold; }
            QPushButton:hover { background-color: #333; color: white; border-color: #888; }
        """)
        back_btn.clicked.connect(lambda: QTimer.singleShot(150, self.back_to_main.emit))

        header_layout.addWidget(title_lbl)
        header_layout.addWidget(subtitle_lbl)
        header_layout.addStretch()
        header_layout.addWidget(back_btn)

        main_layout.addWidget(header_container)

        # --- 2. Chat Area ---
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea { border: none; background-color: #181818; }
            QScrollBar:vertical { width: 10px; background: #222; }
            QScrollBar::handle:vertical { background: #555; border-radius: 5px; }
        """)

        self.history_container = QWidget()
        self.history_container.setStyleSheet("background-color: #181818;")
        self.history_layout = QVBoxLayout(self.history_container)
        self.history_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.history_layout.setSpacing(15)
        self.history_layout.setContentsMargins(30, 30, 30, 30)

        self.scroll_area.setWidget(self.history_container)
        main_layout.addWidget(self.scroll_area, stretch=1)

        # --- 3. Input Area ---
        input_container = QWidget()
        input_container.setStyleSheet("background-color: #252526; border-top: 1px solid #333;")
        input_layout = QHBoxLayout(input_container)
        input_layout.setContentsMargins(20, 15, 20, 15)
        input_layout.setSpacing(15)

        self.message_in = QTextEdit()
        self.message_in.setPlaceholderText("Type your message here...")
        self.message_in.setFixedHeight(60)
        self.message_in.setStyleSheet("""
            QTextEdit { background-color: #333; border: none; border-radius: 8px; color: white; padding: 10px; font-size: 14px; }
            QTextEdit:focus { background-color: #3a3a3a; border: 1px solid #0078d4; }
        """)

        # Buttons Container
        btns_layout = QVBoxLayout()
        btns_layout.setSpacing(5)

        # Button 1: Send Message (General)
        self.send_msg_btn = QPushButton("Send Message")
        self.send_msg_btn.setFixedSize(140, 30)
        self.send_msg_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_msg_btn.setStyleSheet("""
            QPushButton { background-color: #0078d4; color: white; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #005a9e; }
        """)
        self.send_msg_btn.clicked.connect(lambda: self.send_message(is_ticket=False))

        # Button 2: Submit Ticket (Problem)
        self.submit_ticket_btn = QPushButton("⚠ Submit Ticket")
        self.submit_ticket_btn.setFixedSize(140, 30)
        self.submit_ticket_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.submit_ticket_btn.setStyleSheet("""
            QPushButton { background-color: #e74c3c; color: white; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #c0392b; }
        """)
        self.submit_ticket_btn.clicked.connect(lambda: self.send_message(is_ticket=True))

        btns_layout.addWidget(self.send_msg_btn)
        btns_layout.addWidget(self.submit_ticket_btn)

        input_layout.addWidget(self.message_in)
        input_layout.addLayout(btns_layout)

        main_layout.addWidget(input_container)

    def set_user_details(self, name, email):
        self.current_name = name
        self.current_email = email
        self.refresh_history()

    def refresh_history(self):
        while self.history_layout.count():
            item = self.history_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

        if not self.current_email: return
        messages = self.manager.get_my_messages(self.current_email)

        for msg in messages:
            # Determine if this message is a Ticket or General Chat
            raw_text = msg['message_text']
            is_ticket_type = raw_text.startswith("[TICKET]")

            # Clean display text
            display_text = raw_text.replace("[TICKET] ", "") if is_ticket_type else raw_text

            is_resolved = bool(msg['admin_reply'])

            # 1. User Message (Right Side)
            self.add_message_bubble(display_text, True, msg['timestamp'], msg['id'], is_resolved, is_ticket_type)

            # 2. Admin Reply (Left Side)
            if msg['admin_reply']:
                self.add_message_bubble(msg['admin_reply'], False, None, None, False, False)

        QTimer.singleShot(100, self.scroll_to_bottom)

    def add_message_bubble(self, text, is_own, timestamp, ticket_id, is_resolved, is_ticket_type):
        bubble_row = QHBoxLayout()

        if is_own:
            bubble_row.addStretch()

            if is_ticket_type:
                # --- TICKET CARD STYLE (For Problems) ---
                status_text = "🟢 Resolved" if is_resolved else "🟠 Ticket Open"
                status_color = "#2ecc71" if is_resolved else "#e67e22"
                border_color = "#e74c3c"  # Red border for tickets

                card = QFrame()
                card.setFixedWidth(400)
                card.setStyleSheet(f"""
                    QFrame {{
                        background-color: #2b2b2b;
                        border-left: 5px solid {border_color};
                        border-radius: 8px;
                    }}
                """)
                card_layout = QVBoxLayout(card)
                card_layout.setContentsMargins(15, 12, 15, 12)
                card_layout.setSpacing(8)

                # Header
                header_row = QHBoxLayout()
                id_lbl = QLabel(f"TICKET #{ticket_id}")
                id_lbl.setStyleSheet("color: #e74c3c; font-weight: bold; font-size: 11px;")

                date_str = timestamp.strftime("%b %d, %H:%M") if timestamp else ""
                date_lbl = QLabel(date_str)
                date_lbl.setStyleSheet("color: #777; font-size: 11px;")

                header_row.addWidget(id_lbl)
                header_row.addStretch()
                header_row.addWidget(date_lbl)
                card_layout.addLayout(header_row)

                # Separator
                line = QFrame()
                line.setFixedHeight(1)
                line.setStyleSheet("background-color: #383838;")
                card_layout.addWidget(line)

                # Body
                msg_lbl = QLabel(text)
                msg_lbl.setWordWrap(True)
                msg_lbl.setStyleSheet("color: #ddd; font-size: 14px; border: none;")
                card_layout.addWidget(msg_lbl)

                # Status Footer
                status_lbl = QLabel(status_text)
                status_lbl.setStyleSheet(f"color: {status_color}; font-weight: bold; font-size: 11px; margin-top: 5px;")
                status_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
                card_layout.addWidget(status_lbl)

                bubble_row.addWidget(card)

            else:
                # --- SIMPLE CHAT BUBBLE STYLE (For General Messages) ---
                bubble = QLabel(text)
                bubble.setWordWrap(True)
                bubble.setMaximumWidth(450)
                bubble.setStyleSheet("""
                    QLabel {
                        background-color: #0078d4;
                        color: white;
                        border-radius: 12px;
                        padding: 10px 15px;
                        font-size: 14px;
                    }
                """)
                bubble_row.addWidget(bubble)

        else:
            # --- ADMIN / SUPPORT AGENT STYLE ---
            agent_icon = QLabel("👨‍💼")
            agent_icon.setFixedSize(35, 35)
            agent_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            agent_icon.setStyleSheet("background-color: #444; border-radius: 17px; font-size: 20px;")
            bubble_row.addWidget(agent_icon, alignment=Qt.AlignmentFlag.AlignTop)

            bubble = QLabel(text)
            bubble.setWordWrap(True)
            bubble.setMaximumWidth(500)
            bubble.setStyleSheet("""
                QLabel {
                    background-color: #3a3a3a;
                    color: white;
                    border-radius: 12px;
                    padding: 12px 16px;
                    font-size: 14px;
                    border: 1px solid #555;
                }
            """)
            bubble_row.addWidget(bubble)
            bubble_row.addStretch()

        self.history_layout.addLayout(bubble_row)

    def send_message(self, is_ticket):
        text = self.message_in.toPlainText().strip()
        if not text: return

        # If it's a ticket, we prepend a tag so we can identify it later
        final_text = f"[TICKET] {text}" if is_ticket else text

        try:
            self.manager.save_message(self.current_name, self.current_email, final_text)
            self.refresh_history()
            self.message_in.clear()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def scroll_to_bottom(self):
        scrollbar = self.scroll_area.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


class ActiveRentalsTab(BaseWidget):
    rental_returned = pyqtSignal()

    def __init__(self, manager):
        super().__init__()
        self.manager = manager
        self.all_txns = []
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        # --- Header Layout with Search & Filter ---
        header_layout = QHBoxLayout()
        header_layout.addWidget(self.create_label("Rental Management", True, 16))

        header_layout.addStretch()

        # 1. Status Filter Dropdown
        self.status_filter = QComboBox()
        self.status_filter.addItem("🔑 Keys Out (Active)", "Active")
        self.status_filter.addItem("✅ Returned (History)", "Returned")
        self.status_filter.addItem("Show All Records", "All")

        self.status_filter.setFixedWidth(200)
        self.status_filter.setCursor(Qt.CursorShape.PointingHandCursor)
        self.status_filter.setStyleSheet("""
            QComboBox { 
                background-color: #252526; 
                border: 1px solid #555; 
                border-radius: 4px; 
                padding: 6px; 
                color: white; 
                font-weight: bold;
            }
            QComboBox::drop-down { border: none; }
            QComboBox QAbstractItemView { 
                background-color: #252526; 
                selection-background-color: #0078d4; 
                color: white; 
            }
        """)
        self.status_filter.currentIndexChanged.connect(self.filter_table)
        header_layout.addWidget(self.status_filter)

        header_layout.addSpacing(10)

        # 2. Search Bar (Updated Placeholder)
        self.search_bar = QLineEdit()
        # --- FIX: Updated placeholder to indicate ID is searchable ---
        self.search_bar.setPlaceholderText("🔍 Search ID, Customer, or Car...")
        self.search_bar.setFixedWidth(250)
        self.search_bar.setStyleSheet(
            "QLineEdit { background-color: #252526; border: 1px solid #555; border-radius: 4px; padding: 6px; color: white; }")

        self.search_bar.textChanged.connect(self.filter_table)

        header_layout.addWidget(self.search_bar)
        layout.addLayout(header_layout)
        # --- End Header Layout ---

        # 3. Table Setup
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels(
            ["ID", "Customer", "Car Model", "Date Rented", "Total Days", "Return Date", "Status", "Action"])
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)

        # Increase column width slightly for the button
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(7, 140)

        v_header = self.table.verticalHeader()
        v_header.setVisible(False)
        v_header.setDefaultSectionSize(45)
        v_header.setSectionResizeMode(QHeaderView.ResizeMode.Fixed)

        self.table.setStyleSheet("""
            QTableWidget { border: 1px solid #444; gridline-color: #444; background-color: #1e1e1e; color: #ddd; }
            QHeaderView::section { background-color: #2d2d2d; padding: 4px; border: 1px solid #333; font-weight: bold; color: #eee; }
            QTableWidget::item { padding: 2px 5px; }
        """)
        layout.addWidget(self.table)

    def populate_table(self):
        self.all_txns = self.manager.get_all_transactions()
        self.table.setRowCount(len(self.all_txns))

        for row, txn in enumerate(self.all_txns):
            # 1. ID
            id_item = QTableWidgetItem(str(txn.id))
            id_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 0, id_item)

            # 2. User
            self.table.setItem(row, 1, QTableWidgetItem(txn.user.get('name', 'Unknown')))

            # 3. Car
            self.table.setItem(row, 2, QTableWidgetItem(txn.car.name))

            # 4. Dates
            try:
                rent_date = txn.timestamp.strftime("%Y-%m-%d")
                return_date_obj = txn.timestamp + timedelta(days=txn.duration)
                return_date = return_date_obj.strftime("%Y-%m-%d")
            except:
                rent_date = str(txn.timestamp)
                return_date = "N/A"

            rent_item = QTableWidgetItem(rent_date)
            rent_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 3, rent_item)

            days_item = QTableWidgetItem(f"{txn.duration} Days")
            days_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 4, days_item)

            return_item = QTableWidgetItem(return_date)
            return_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 5, return_item)

            # 5. Status
            db_status = txn.status

            status_item = QTableWidgetItem(db_status)
            status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            status_item.setFont(QFont("Arial", 9, QFont.Weight.Bold))

            if db_status == "Active":
                status_item.setText("Keys Out")
                status_item.setForeground(QColor("#e67e22"))
                status_item.setData(Qt.ItemDataRole.UserRole, "Active")
            else:
                status_item.setForeground(QColor("#3498db"))
                status_item.setData(Qt.ItemDataRole.UserRole, "Returned")

            self.table.setItem(row, 6, status_item)

            # 6. Action Button
            if db_status == "Active":
                btn = QPushButton("Return Vehicle")
                btn.setCursor(Qt.CursorShape.PointingHandCursor)
                btn.setFixedHeight(32)
                btn.setStyleSheet("""
                    QPushButton { 
                        background-color: #27ae60; 
                        color: white; 
                        font-weight: bold; 
                        border-radius: 4px; 
                        font-size: 11px; 
                        padding: 0 5px;
                    } 
                    QPushButton:hover { background-color: #219150; }
                """)
                btn.clicked.connect(lambda _, r=row: self.handle_return(r))

                btn_widget = QWidget()
                btn_layout = QHBoxLayout(btn_widget)
                btn_layout.setContentsMargins(5, 2, 5, 2)
                btn_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
                btn_layout.addWidget(btn)
                self.table.setCellWidget(row, 7, btn_widget)
            else:
                lbl = QLabel("Completed")
                lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
                lbl.setStyleSheet("color: #666; font-size: 10px; font-style: italic;")
                self.table.setCellWidget(row, 7, lbl)

        self.filter_table()

    # --- UPDATED SEARCH LOGIC ---
    def filter_table(self):
        search_text = self.search_bar.text().lower().strip()
        filter_mode = self.status_filter.currentData()

        for row in range(self.table.rowCount()):
            # Get items from ID, Customer, and Car columns
            id_item = self.table.item(row, 0)         # Column 0: ID
            customer_item = self.table.item(row, 1)   # Column 1: Customer
            car_model_item = self.table.item(row, 2)  # Column 2: Car Model

            if not id_item or not customer_item or not car_model_item:
                self.table.setRowHidden(row, True)
                continue

            # Check if search text exists in ANY of the three columns
            id_text = id_item.text().lower()
            customer_text = customer_item.text().lower()
            car_text = car_model_item.text().lower()

            # The FIX: Added `or (search_text in id_text)`
            text_match = (search_text in id_text) or (search_text in customer_text) or (search_text in car_text)

            # Check Status Filter
            status_item = self.table.item(row, 6)
            row_status = status_item.data(Qt.ItemDataRole.UserRole)

            if filter_mode == "All":
                status_match = True
            else:
                status_match = (row_status == filter_mode)

            self.table.setRowHidden(row, not (text_match and status_match))

    def handle_return(self, row):
        txn_id_item = self.table.item(row, 0)
        if not txn_id_item: return

        txn_id = int(txn_id_item.text())
        car_name = self.table.item(row, 2).text()

        reply = QMessageBox.question(self, "Confirm Return",
                                     f"Mark '{car_name}' as returned?\nThis will increment stock.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            result = self.manager.return_rental(txn_id, car_name)
            if result is True:
                QMessageBox.information(self, "Success", "Vehicle returned and stock updated.")
                self.populate_table()
                self.rental_returned.emit()
            else:
                QMessageBox.critical(self, "Error", f"Failed: {result}")


class AdminDashboardWidget(BaseWidget):
    availability_updated = pyqtSignal()
    services_updated = pyqtSignal()
    signout_requested = pyqtSignal()

    def __init__(self, rental_manager):
        super().__init__()
        self.manager = rental_manager
        main_layout = QHBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)

        self.sidebar = QWidget()
        self.sidebar.setFixedWidth(250)
        self.sidebar.setStyleSheet("background-color: #1e1e1e; border-right: 1px solid #333;")
        sidebar_layout = QVBoxLayout(self.sidebar)
        sidebar_layout.setContentsMargins(0, 20, 0, 20)
        sidebar_layout.setSpacing(10)

        title_lbl = QLabel("ADMIN DASHBOARD")
        title_lbl.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        title_lbl.setStyleSheet("color: #888; letter-spacing: 1px; padding-left: 20px; border: none;")
        sidebar_layout.addWidget(title_lbl)
        sidebar_layout.addSpacing(20)

        self.sales_btn = self._create_nav_button("   📈   Sales Report")
        self.active_rentals_btn = self._create_nav_button("   🔑   Active Rentals")
        self.availability_btn = self._create_nav_button("   🛠️   Inventory")
        self.messages_btn = self._create_nav_button("   💬   Messages")

        self.sales_btn.clicked.connect(self._go_to_sales)
        self.active_rentals_btn.clicked.connect(self._go_to_active_rentals)
        self.availability_btn.clicked.connect(self._go_to_inventory)
        self.messages_btn.clicked.connect(self._go_to_messages)

        sidebar_layout.addWidget(self.sales_btn)
        sidebar_layout.addWidget(self.active_rentals_btn)
        sidebar_layout.addWidget(self.availability_btn)
        sidebar_layout.addWidget(self.messages_btn)
        sidebar_layout.addStretch(1)

        signout_btn = QPushButton("   🚪   Sign Out")
        signout_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        signout_btn.setFixedHeight(50)
        signout_btn.setStyleSheet(
            "QPushButton { background-color: transparent; color: #e74c3c; text-align: left; padding-left: 20px; font-weight: bold; font-size: 14px; border: none; } QPushButton:hover { background-color: #2c0b0b; border-left: 4px solid #e74c3c; }")
        signout_btn.clicked.connect(self.signout_requested.emit)
        sidebar_layout.addWidget(signout_btn)
        main_layout.addWidget(self.sidebar)

        content_area = QWidget()
        content_area.setStyleSheet("background-color: transparent; border: none;")
        content_layout = QVBoxLayout(content_area)
        content_layout.setContentsMargins(30, 30, 30, 30)

        self.stacked_sections = QStackedWidget()
        self.sales_tab = SalesReportTab(self.manager)
        self.active_rentals_tab = ActiveRentalsTab(self.manager)
        self.inventory_tab = InventoryTab(self.manager)
        self.messages_tab = MessagesTab(self.manager)

        self.stacked_sections.addWidget(self.sales_tab)
        self.stacked_sections.addWidget(self.active_rentals_tab)
        self.stacked_sections.addWidget(self.inventory_tab)
        self.stacked_sections.addWidget(self.messages_tab)

        content_layout.addWidget(self.stacked_sections)
        main_layout.addWidget(content_area)

        self.active_rentals_tab.rental_returned.connect(self.inventory_tab.populate_availability_table)
        self.inventory_tab.availability_updated.connect(self.availability_updated.emit)
        self.inventory_tab.services_updated.connect(self.services_updated.emit)
        self._go_to_sales()

    def _create_nav_button(self, text):
        btn = QPushButton(text)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setFixedHeight(55)
        btn.setFont(QFont("Arial", 11))
        btn.setStyleSheet(
            "QPushButton { background-color: transparent; color: #ccc; text-align: left; padding-left: 20px; border: none; border-left: 4px solid transparent; } QPushButton:hover { background-color: #2a2a2a; color: white; }")
        return btn

    def _update_active_button(self, active_btn):
        for btn in [self.sales_btn, self.active_rentals_btn, self.availability_btn, self.messages_btn]:
            btn.setStyleSheet(
                "QPushButton { background-color: transparent; color: #ccc; text-align: left; padding-left: 20px; border: none; border-left: 4px solid transparent; } QPushButton:hover { background-color: #2a2a2a; color: white; }")
        active_btn.setStyleSheet(
            "QPushButton { background-color: #252526; color: white; text-align: left; padding-left: 20px; border: none; border-left: 4px solid #0078d4; font-weight: bold; }")

    def _go_to_sales(self):
        self.sales_tab.handle_reset()
        self.stacked_sections.setCurrentWidget(self.sales_tab)
        self._update_active_button(self.sales_btn)

    def _go_to_active_rentals(self):
        self.active_rentals_tab.populate_table()
        self.stacked_sections.setCurrentWidget(self.active_rentals_tab)
        self._update_active_button(self.active_rentals_btn)

    def _go_to_inventory(self):
        self.inventory_tab.populate_categories_dropdown()
        self.inventory_tab.populate_availability_table()
        self.inventory_tab.populate_services_table()
        self.stacked_sections.setCurrentWidget(self.inventory_tab)
        self._update_active_button(self.availability_btn)

    def _go_to_messages(self):
        self.messages_tab.populate_message_table()
        self.stacked_sections.setCurrentWidget(self.messages_tab)
        self._update_active_button(self.messages_btn)


# --- Helper Class for Floating Calendar ---
class DatePopup(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.cal = QCalendarWidget()
        self.cal.setGridVisible(False)
        self.cal.setVerticalHeaderFormat(QCalendarWidget.VerticalHeaderFormat.NoVerticalHeader)
        self.cal.setFixedSize(300, 220)  # Compact size

        # Clean White Style
        self.cal.setStyleSheet("""
            QCalendarWidget QWidget { 
                background-color: #ffffff; 
                color: black; 
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QCalendarWidget QWidget#qt_calendar_navigationbar { 
                background-color: #f0f0f0; 
                border-bottom: 1px solid #ddd;
            }
            QCalendarWidget QToolButton {
                color: #333;
                font-weight: bold;
                icon-size: 16px;
                background-color: transparent; 
                border: none;
            }
            QCalendarWidget QToolButton:hover {
                background-color: #e0e0e0;
                border-radius: 4px;
            }
            QCalendarWidget QAbstractItemView {
                selection-background-color: #3498db; 
                selection-color: white; 
                font-size: 12px;
            }
        """)

        layout.addWidget(self.cal)
        self.cal.clicked.connect(self.accept)  # Close when a date is clicked

    def get_date(self):
        return self.cal.selectedDate()

    def set_date(self, date):
        self.cal.setSelectedDate(date)


# --- Main Options Widget ---
class DatePopup(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.cal = QCalendarWidget()
        self.cal.setGridVisible(False)
        self.cal.setVerticalHeaderFormat(QCalendarWidget.VerticalHeaderFormat.NoVerticalHeader)
        self.cal.setFixedSize(300, 240)

        # --- FIXED STYLESHEET ---
        self.cal.setStyleSheet("""
            QCalendarWidget QWidget { 
                background-color: #ffffff; 
                color: black; 
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QCalendarWidget QWidget#qt_calendar_navigationbar { 
                background-color: #f0f0f0; 
                border-bottom: 1px solid #ddd;
            }
            QCalendarWidget QToolButton {
                color: #333;
                font-weight: bold;
                font-size: 12px;
                icon-size: 20px;
                background-color: transparent; 
                border: none;
                padding: 5px;
                margin: 2px;
            }
            QCalendarWidget QToolButton:hover {
                background-color: #e0e0e0;
                border-radius: 4px;
            }
            /* THIS FIXES THE OVERLAPPING ARROW */
            QCalendarWidget QToolButton::menu-indicator {
                image: none;
            }
            QCalendarWidget QAbstractItemView {
                selection-background-color: #3498db; 
                selection-color: white; 
                font-size: 12px;
                outline: 0;
            }
        """)

        layout.addWidget(self.cal)
        self.cal.clicked.connect(self.accept)

    def get_date(self):
        return self.cal.selectedDate()

    def set_date(self, date):
        self.cal.setSelectedDate(date)


# --- Main Options Widget ---
class OptionsWidget(BaseWidget):
    booking_confirmed = pyqtSignal(dict)
    back_to_vehicles = pyqtSignal()

    def __init__(self, rental_manager):
        super().__init__()
        self.manager = rental_manager
        self.selected_car = None
        self.service_rows = []

        # Default dates
        self.current_start_date = QDate.currentDate()
        self.current_end_date = QDate.currentDate().addDays(1)

        self.setup_ui()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self.content_widget = QWidget()
        self.content_widget.setStyleSheet("background-color: transparent;")

        content_layout = QVBoxLayout(self.content_widget)
        content_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
        content_layout.setContentsMargins(20, 40, 20, 40)

        form_container = QWidget()
        form_container.setFixedWidth(750)
        form_container.setStyleSheet("background: transparent;")

        form_layout = QVBoxLayout(form_container)
        form_layout.setSpacing(25)

        # 1. Car Image
        self.car_img_lbl = QLabel()
        self.car_img_lbl.setFixedSize(750, 420)
        self.car_img_lbl.setStyleSheet("background-color: #222; border-radius: 12px; border: 1px solid #333;")
        self.car_img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        form_layout.addWidget(self.car_img_lbl)

        # 2. Car Info
        self.car_name_lbl = QLabel("Car Name")
        self.car_name_lbl.setFont(QFont("Segoe UI", 26, QFont.Weight.Bold))
        self.car_name_lbl.setStyleSheet("color: white; background: transparent;")
        self.car_name_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.car_price_lbl = QLabel("P0.00 / day")
        self.car_price_lbl.setStyleSheet("color: #0078d4; font-size: 18px; font-weight: bold; background: transparent;")
        self.car_price_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        form_layout.addWidget(self.car_name_lbl)
        form_layout.addWidget(self.car_price_lbl)

        line = QLabel()
        line.setFixedHeight(1)
        line.setStyleSheet("background-color: #444;")
        form_layout.addWidget(line)

        # --- 3. POPUP CALENDAR SECTION ---

        lbl_period = QLabel("SELECT RENTAL DATES")
        lbl_period.setStyleSheet("color: #888; font-weight: bold; letter-spacing: 1px; font-size: 12px;")
        form_layout.addWidget(lbl_period)

        cal_layout = QHBoxLayout()
        cal_layout.setSpacing(40)
        cal_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        # Button Style
        btn_style = """
            QPushButton {
                background-color: #252526;
                border: 1px solid #555;
                border-radius: 6px;
                color: white;
                font-size: 14px;
                font-weight: bold;
                text-align: left;
                padding-left: 15px;
            }
            QPushButton:hover { border: 1px solid #0078d4; background-color: #2a2a2a; }
        """

        # -- START DATE --
        start_container = QWidget()
        start_layout = QVBoxLayout(start_container)
        start_layout.setContentsMargins(0, 0, 0, 0)
        start_layout.setSpacing(5)

        start_lbl = QLabel("Start Date")
        start_lbl.setStyleSheet("color: #bbb; font-weight: bold;")

        self.btn_start_date = QPushButton("📅  Select Date")
        self.btn_start_date.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start_date.setFixedSize(300, 45)
        self.btn_start_date.setStyleSheet(btn_style)
        self.btn_start_date.clicked.connect(self.open_start_calendar)

        start_layout.addWidget(start_lbl)
        start_layout.addWidget(self.btn_start_date)
        cal_layout.addWidget(start_container)

        # -- END DATE --
        end_container = QWidget()
        end_layout = QVBoxLayout(end_container)
        end_layout.setContentsMargins(0, 0, 0, 0)
        end_layout.setSpacing(5)

        end_lbl = QLabel("End Date")
        end_lbl.setStyleSheet("color: #bbb; font-weight: bold;")

        self.btn_end_date = QPushButton("📅  Select Date")
        self.btn_end_date.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_end_date.setFixedSize(300, 45)
        self.btn_end_date.setStyleSheet(btn_style)
        self.btn_end_date.clicked.connect(self.open_end_calendar)

        end_layout.addWidget(end_lbl)
        end_layout.addWidget(self.btn_end_date)
        cal_layout.addWidget(end_container)

        form_layout.addLayout(cal_layout)
        # ---------------------------------------------------------

        addons_label = QLabel("Available Add-ons:")
        addons_label.setStyleSheet("color: #ccc; font-size: 14px; margin-top: 15px; background: transparent;")
        form_layout.addWidget(addons_label)

        self.services_layout = QVBoxLayout()
        self.services_layout.setSpacing(10)
        form_layout.addLayout(self.services_layout)

        form_layout.addStretch(1)

        # Bottom Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(15)

        self.back_btn = QPushButton("Back")
        self.back_btn.setFixedSize(120, 50)
        self.back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.back_btn.setStyleSheet(
            "QPushButton { background-color: transparent; border: 1px solid #555; color: #ccc; border-radius: 6px; font-weight: bold; } QPushButton:hover { border: 1px solid #888; color: white; }")

        self.back_btn.clicked.connect(lambda: QTimer.singleShot(150, self.back_to_vehicles.emit))

        self.confirm_btn = QPushButton("Confirm Booking")
        self.confirm_btn.setFixedHeight(50)
        self.confirm_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.confirm_btn.setStyleSheet(
            "QPushButton { background-color: #0078d4; color: white; border-radius: 6px; font-weight: bold; font-size: 16px; } QPushButton:hover { background-color: #005a9e; }")
        self.confirm_btn.clicked.connect(self.confirm_and_book)

        btn_layout.addWidget(self.back_btn)
        btn_layout.addWidget(self.confirm_btn)
        form_layout.addLayout(btn_layout)

        content_layout.addWidget(form_container)
        self.scroll_area.setWidget(self.content_widget)
        main_layout.addWidget(self.scroll_area)

    def update_date_buttons(self):
        s_date = self.current_start_date.toString("yyyy-MMM-dd")
        e_date = self.current_end_date.toString("yyyy-MMM-dd")
        self.btn_start_date.setText(f"📅  {s_date}")
        self.btn_end_date.setText(f"📅  {e_date}")

    def open_start_calendar(self):
        popup = DatePopup(self)
        popup.set_date(self.current_start_date)
        popup.cal.setMinimumDate(QDate.currentDate())

        pos = self.btn_start_date.mapToGlobal(self.btn_start_date.rect().bottomLeft())
        popup.move(pos)

        if popup.exec():
            new_start = popup.get_date()
            self.current_start_date = new_start
            if self.current_end_date <= new_start:
                self.current_end_date = new_start.addDays(1)
            self.update_date_buttons()

    def open_end_calendar(self):
        popup = DatePopup(self)
        popup.set_date(self.current_end_date)
        popup.cal.setMinimumDate(self.current_start_date.addDays(1))

        pos = self.btn_end_date.mapToGlobal(self.btn_end_date.rect().bottomLeft())
        popup.move(pos)

        if popup.exec():
            self.current_end_date = popup.get_date()
            self.update_date_buttons()

    def update_view(self, car):
        self.selected_car = car
        self.car_name_lbl.setText(car.name)
        p = car.price_per_day if car.price_per_day is not None else 0.0
        self.car_price_lbl.setText(f"{format_peso(p)} / day")

        # Reset Dates
        self.current_start_date = QDate.currentDate()
        self.current_end_date = QDate.currentDate().addDays(1)
        self.update_date_buttons()

        self.car_img_lbl.setPixmap(load_car_pixmap(car.image_path, 750, 420))
        self.refresh_services_list()

        self.confirm_btn.setEnabled(True)
        self.confirm_btn.setText("Confirm Booking")

    def refresh_services_list(self):
        while self.services_layout.count():
            item = self.services_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

        self.service_rows.clear()
        services = self.manager.get_services()

        if not services:
            lbl = QLabel("No add-ons available.")
            lbl.setStyleSheet("color: #666; font-style: italic; background: transparent;")
            self.services_layout.addWidget(lbl)
            return

        for svc in services:
            row = ServiceListItem(svc)
            self.services_layout.addWidget(row)
            self.service_rows.append(row)

    def confirm_and_book(self):
        self.confirm_btn.setEnabled(False)
        self.confirm_btn.setText("Processing...")
        self.confirm_btn.repaint()

        if not self.selected_car:
            return

        q_start_date = self.current_start_date
        q_end_date = self.current_end_date
        days = q_start_date.daysTo(q_end_date)

        if days <= 0:
            QMessageBox.warning(self, "Error", "The End Date must be after the Start Date.")
            self._reset_button()
            return

        start_date_str = q_start_date.toString("yyyy-MMM-dd")
        end_date_str = q_end_date.toString("yyyy-MMM-dd")

        try:
            raw_car_price = self.selected_car.price_per_day
            base_price = float(raw_car_price) if raw_car_price is not None else 0.0
            base_total = float(base_price * days)

            services_selected = []
            services_total = 0.0

            for row in self.service_rows:
                if row.is_checked:
                    svc = row.service_data
                    raw_svc_price = svc.get('price')
                    svc_price = float(raw_svc_price) if raw_svc_price is not None else 0.0

                    raw_daily = svc.get('is_daily', False)
                    if isinstance(raw_daily, str):
                        is_daily = raw_daily.lower() in ('1', 'true', 't', 'yes', 'y')
                    elif isinstance(raw_daily, int):
                        is_daily = (raw_daily == 1)
                    else:
                        is_daily = bool(raw_daily)

                    cost = float(svc_price * days if is_daily else svc_price)

                    services_total += cost
                    services_selected.append({"name": svc.get('name', 'Add-on'), "cost": cost})

            final_total = float(base_total + services_total)

            booking_data = {
                "car": self.selected_car,
                "duration": days,
                "base_total": base_total,
                "services": services_selected,
                "final_total": final_total,
                "start_date": start_date_str,
                "end_date": end_date_str
            }

            QTimer.singleShot(200, lambda: self.booking_confirmed.emit(booking_data))

        except Exception as e:
            QMessageBox.critical(self, "Calculation Error", f"An error occurred:\n{str(e)}")
            self._reset_button()

    def _reset_button(self):
        self.confirm_btn.setEnabled(True)
        self.confirm_btn.setText("Confirm Booking")